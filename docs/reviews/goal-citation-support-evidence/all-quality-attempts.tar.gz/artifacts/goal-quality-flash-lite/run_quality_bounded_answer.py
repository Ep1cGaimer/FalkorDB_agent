"""Four distinct development quality questions, paired graph/plaintext, test model only.

No application endpoint, environment file, or model setting is modified. A new
owned ephemeral database supplies a disposable comparison index. Only public
inspected development source is used; source-derived expectations precede calls.
"""
import ast,concurrent.futures,dataclasses,datetime,hashlib,json,os,random,ssl,subprocess,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.repo.git import GitRepo
from rw.repo.index import index_repository
from confirmatory.plaintext_tools import PlaintextTools
from confirmatory.graph_tools import GraphTools,config_for_export
from confirmatory.development_cli import plaintext_capabilities
from confirmatory.gemini_meter import GeminiAPI,Journal,MeteredModel,ModelLimits
from confirmatory.investigation_runner import run_development_question
from confirmatory.citation_guard import CitationGuard

root=Path.cwd();out=root/'artifacts/goal-quality-flash-lite/run-005-bounded-answer';out.mkdir(parents=True,exist_ok=False)
model_name='models/gemini-3.1-flash-lite'
export=root/'artifacts/corpus-development/itsdangerous-full-001'
raw=PlaintextTools(export);sha=raw.spec['roots'][0]
git=GitRepo(root/'artifacts/repos/itsdangerous')
def write(path,value):path.write_text(json.dumps(value,indent=2,default=str)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
pin=json.loads((root/'artifacts/goal-source-preflight/implementation-manifest.json').read_text())['files']
pin={p:digest(root/p) for p in sorted(set(pin)|{'evals/confirmatory/paired_scores.py','tests/test_confirmatory_paired_scores.py'})}
write(out/'source-before.json',{'files':pin})
# Independent of graph output: direct Git source and AST identify declared paths/spans.
oracle={'classification':'PARENT_SOURCE_DERIVED_DEVELOPMENT_ORACLE_NOT_INDEPENDENT_HELDOUT',
        'repository':raw.repository,'commit':sha,'sources':{}}
for path in ['src/itsdangerous/url_safe.py','src/itsdangerous/timed.py','src/itsdangerous/serializer.py','src/itsdangerous/signer.py']:
    data=git._bytes('show',sha+':'+path)
    tree=ast.parse(data.decode());facts=[]
    for node in tree.body:
        if isinstance(node,ast.ClassDef):
            facts.append({'class':node.name,'start':node.lineno,'end':node.end_lineno,
                          'bases':[ast.unparse(base) for base in node.bases],
                          'methods':[{'name':x.name,'start':x.lineno,'end':x.end_lineno} for x in node.body
                                     if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name in {'unsign','loads'}]})
    oracle['sources'][path]={'content_hash':hashlib.sha256(data).hexdigest(),'facts':facts}
oracle['expectations']={
 'DEV-LITE-MULTIHOP':{'required':['URLSafeTimedSerializer → TimedSerializer → Serializer',
      'URLSafeTimedSerializer → URLSafeSerializerMixin → Serializer','source citations at selected commit',
      'declared/static relationship evidence; no runtime MRO/compatibility claim']},
 'DEV-LITE-AMBIGUOUS':{'required':['unsign belongs to both Signer and TimestampSigner',
      'clarify class or show both candidates; do not silently choose one','overload declarations are not separate implementations']},
 'DEV-LITE-MISSING-REV':{'required':['the requested nonexistent revision is unresolved','no substitution of selected/current revision','no invented citation at missing commit']},
 'DEV-LITE-STATIC-LIMIT':{'required':['static graph cannot prove exhaustive runtime callback/callee coverage',
      'explicit limitation/uncertainty','no definitive absence or source-only compatibility pass']}}
write(out/'expected-before-runs.json',oracle)
tasks=[
 {'id':'DEV-LITE-MULTIHOP','repository':raw.repository,'revision':sha,
  'question':'At this exact revision, explain two distinct two-hop inheritance routes from URLSafeTimedSerializer to Serializer. Cite the source declarations behind each route. Distinguish static source relationships from runtime verification.'},
 {'id':'DEV-LITE-AMBIGUOUS','repository':raw.repository,'revision':sha,
  'question':'Where is unsign defined at this revision? I have not specified a class. Give the relevant candidates or ask for the missing choice instead of silently choosing one; cite any candidates you report.'},
 {'id':'DEV-LITE-MISSING-REV','repository':raw.repository,'revision':'f'*40,
  'question':'At the exact requested revision, where is URLSafeTimedSerializer defined? Do not substitute another revision if the requested one is unavailable.'},
 {'id':'DEV-LITE-STATIC-LIMIT','repository':raw.repository,'revision':sha,
  'question':'Can the available static dependency evidence prove that Serializer.loads has no additional runtime callees or callbacks? Investigate what the evidence supports, cite material source claims, and explain any missing coverage rather than treating missing edges as proof.'}]
tasks=[t for t in tasks if t['id']!='DEV-LITE-MISSING-REV']
write(out/'tasks.json',tasks)
order=[];rng=random.Random(682410)
for task in tasks:
    arms=['graph','plaintext'];rng.shuffle(arms);order.append({'task':task['id'],'arms':arms})
write(out/'predeclared-plan.json',{'model':model_name,'generation':{'temperature':0,'responseMimeType':'application/json'},
 'decision_protocol':'native-application-dispatch-continuation/v2','prior_attempt':'Allrun001-003retained;run003interruptedafterfollowupreadbug;sharedreadtoolnowdefaults endto start+99 inbotharms;evaluator-onlyrepair;no applicationendpointchanges','generation_start_spacing_seconds':6.5,'retrieval_decision_limit':6,'controller_stop':'Record stop then generate bounded answer fromlockedretrieval; explicit limitation required; not autonomousfinishclaim','repeats':1,'classification':'FOCUSED_DEVELOPMENT_QUALITY_NOT_T2_T10',
 'order':order,'paired_same_task_and_model':True,'limits':dataclasses.asdict(ModelLimits(input_tokens=96000,output_tokens=8000,per_call_output=2000,seconds=180)),
 'automatic_retries':0,'endpoint_mutations':0,'oracle_sha256':digest(out/'expected-before-runs.json'),
 'corpus_sha256':raw.corpus_hash,'source_pin_sha256':digest(out/'source-before.json'),
 'scoring':'Source-derived predeclared checklist; parent qualitative review; no independent blind score claimed'})
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
db='rw-quality-flash-lite-bounded-20261018';graph='quality_flash_lite'
record={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'model':model_name,
 'application_endpoint_mutations':0,'owned_database':db,'runs':[],'acceptance_validated':False}
class BoundedAnswerModel(MeteredModel):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.retrieval_decisions=0
        self.controller_stopped=False
    def ask(self,system,contents,*,phase,output_limit=None):
        if phase=='retrieval':
            if self.retrieval_decisions>=6:
                self.controller_stopped=True
                self._native_content=self._native_text=None
                self.journal.append('controller_retrieval_stop',reason='six retrieval decisions reached',evidence_complete=False)
                return '{"action":"finish"}'
            self.retrieval_decisions+=1
        elif self.controller_stopped:
            system+='\nRetrieval was stopped by a declared six-decision controller limit. Include that limitation in gaps. Answer only propositions actually established by the locked evidence; clarify/abstain on unresolved parts. Do not call evidence complete or exhaustive.'
        return super().ask(system,contents,phase=phase,output_limit=output_limit)
class PacedGeminiAPI(GeminiAPI):
    last_start=0.0
    def generate(self,request,timeout):
        delay=max(0,6.5-(time.monotonic()-PacedGeminiAPI.last_start))
        if delay:time.sleep(delay)
        PacedGeminiAPI.last_start=time.monotonic()
        with (out/'pacing.jsonl').open('a') as stream:stream.write(json.dumps({'generation_started_monotonic':PacedGeminiAPI.last_start,'wait_seconds':delay,'retries':0})+'\n')
        return super().generate(request,max(.001,timeout-delay))
try:
    subprocess.run(['docker','run','-d','--name',db,'--memory=2g','-p','127.0.0.1::6379',
       'falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'],check=True,stdout=subprocess.DEVNULL)
    ports=json.loads(subprocess.check_output(['docker','inspect',db,'--format','{{json .NetworkSettings.Ports}}']))
    os.environ['RW_FALKORDB_HOST']='127.0.0.1';os.environ['RW_FALKORDB_PORT']=ports['6379/tcp'][0]['HostPort']
    record['index']=dataclasses.asdict(index_repository(config_for_export(raw,root/'artifacts/repos/itsdangerous'),graph))
    context=ssl.create_default_context();context.maximum_version=ssl.TLSVersion.TLSv1_2
    with httpx.Client(verify=context,follow_redirects=False,timeout=20) as client:
        response=client.get('https://generativelanguage.googleapis.com/v1beta/'+model_name,
                            headers={'x-goog-api-key':os.environ['GEMINI_API_KEY']})
        metadata=response.json() if response.status_code==200 else None
        write(out/'model-metadata.json',{'http_status':response.status_code,'metadata':metadata})
        if response.status_code!=200:raise RuntimeError('requested model metadata unavailable')
    for task,planned in zip(tasks,order):
        for arm in planned['arms']:
            folder=out/(task['id']+'-'+arm)
            journal=Journal(folder);trace=[]
            with httpx.Client(verify=context,follow_redirects=False) as client:
                api=PacedGeminiAPI(model_name,os.environ['GEMINI_API_KEY'],client=client)
                if arm=='graph':
                    tools=GraphTools(raw,graph,trace=trace)
                    capabilities,descriptions=tools.capabilities();readiness=tools.prepare
                else:
                    capabilities,descriptions=plaintext_capabilities(raw);readiness=None
                model=BoundedAnswerModel(api,journal,ModelLimits(input_tokens=96000,output_tokens=8000,per_call_output=2000,seconds=180),generation={'responseMimeType':'application/json','temperature':0},native_decision_tools=sorted(capabilities))
                started=time.monotonic()
                result=run_development_question(task,capabilities,descriptions,model,
                    readiness=readiness,audit_trace=trace if arm=='graph' else None,
                    citation_guard=CitationGuard(raw),corpus_context={'corpus_sha256':raw.corpus_hash,'spec':raw.spec})
            row={'task':task['id'],'arm':arm,'status':result['status'],'failure':result['failure'],
                 'answer_generated':result['answer'] is not None,'seconds':time.monotonic()-started,
                 'result_path':str((folder/'result.json').relative_to(root))}
            record['runs'].append(row);write(out/'progress.json',record);print(json.dumps(row),flush=True)
except Exception as exc:
    record['harness_error']=type(exc).__name__
finally:
    removed=subprocess.run(['docker','rm','-f',db],capture_output=True)
    record['cleanup']={'remove_exit_code':removed.returncode,'remaining':subprocess.check_output(['docker','ps','-a','--filter','name='+db,'--format','{{.Names}}']).decode().splitlines()}
    record['source_mismatches']=[p for p,h in pin.items() if digest(root/p)!=h]
    record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();write(out/'summary.json',record)
    print(json.dumps({'finished':True,'attempts':len(record['runs']),'harness_error':record.get('harness_error'),'source_mismatches':record['source_mismatches']}),flush=True)
