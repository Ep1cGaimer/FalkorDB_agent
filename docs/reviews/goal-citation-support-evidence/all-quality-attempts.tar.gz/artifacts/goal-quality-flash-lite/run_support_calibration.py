"""Exact-span development reviewer calibration; no investigations or endpoints changed."""
import datetime,hashlib,json,os,ssl,time
from pathlib import Path
import httpx
from rw.config import load_env
from confirmatory.plaintext_tools import PlaintextTools
from confirmatory.gemini_meter import GeminiAPI,Journal,MeteredModel,ModelLimits
from confirmatory.claim_support import review_source_claims,SUPPORT_SYSTEM
root=Path.cwd();out=root/'artifacts/goal-quality-flash-lite/support-calibration-001';out.mkdir(exist_ok=False)
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cases=[('sample-A','run-005-typed-reasoning/DEV-LITE-MULTIHOP-graph','all source declarations correctly cited'),
       ('sample-B','run-005-typed-reasoning/DEV-LITE-STATIC-LIMIT-graph','main claimed implementation lies outside final cited spans'),
       ('sample-C','run-006-numbered-reserve/DEV-LITE-STATIC-LIMIT-graph','main implementation cited correctly but parenthetical json default is not in final spans')]
write(out/'plan-before-calls.json',{'classification':'Development evaluator calibration, not new heldout questions or comparative advantage',
 'model':'models/gemini-3.1-flash-lite','source_support_prompt_sha256':hashlib.sha256(SUPPORT_SYSTEM.encode()).hexdigest(),
 'cases':[{'id':name,'source':source,'source_derived_review_expectation':expected} for name,source,expected in cases],
 'independence':'Prior independent nonblind raw-Git reviews; these expectations do not enter reviewer requests',
 'retries':0,'application_endpoint_mutations':0,'changes_application_model':False})
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
raw=PlaintextTools(root/'artifacts/corpus-development/itsdangerous-full-001')
context=ssl.create_default_context();context.maximum_version=ssl.TLSVersion.TLSv1_2
rows=[]
for index,(name,source,_) in enumerate(cases):
 if index:time.sleep(6.5)
 folder=root/'artifacts/goal-quality-flash-lite'/source
 result=json.loads((folder/'result.json').read_text());locked=json.loads((folder/'retrieval.json').read_text())
 with httpx.Client(verify=context,follow_redirects=False) as client:
  api=GeminiAPI('models/gemini-3.1-flash-lite',os.environ['GEMINI_API_KEY'],client=client)
  model=MeteredModel(api,Journal(out/name),ModelLimits(input_tokens=16000,output_tokens=4000,per_call_output=2000,seconds=60,calls=2),generation={'responseMimeType':'application/json','temperature':0})
  review=review_source_claims(result['answer'],locked['tool_trace'],raw,model)
 row={'sample':name,'status':review['status'],'grounding':review['material_claim_grounding'],'errors':review['errors']}
 rows.append(row);print(json.dumps(row),flush=True)
write(out/'summary.json',{'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviews':rows,
 'acceptance_validated':False,'reviewer_accuracy_unvalidated':True,'provider_calls':len(rows)})
