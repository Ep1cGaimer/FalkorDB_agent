"""Actual graph contribution, with exact names discovered from indexed symbols.

Previous audit harness alias lookup mistakes are retained as separate attempts.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from rw import graph as G
from rw.repo.config import RepoConfig
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery

out = {"scope": "fresh representative probes, not held-out acceptance scoring", "repositories": [], "errors": []}
dest = ROOT / "audit/graph-contribution.json"
db = G.connect()
scratch = "audit_graph_contribution_" + uuid.uuid4().hex[:8]
try:
    for name, rev, alias, previous, gname in [
        ("requests", "v2.32.0", "requests.api.get", "v2.31.0", "audit_scale_goal_02"),
        ("itsdangerous", "2.2.0", "itsdangerous.serializer.Serializer.dumps", "2.1.0", scratch),
    ]:
        path = ROOT / "artifacts/repos" / name
        if name == "itsdangerous":
            cfg = RepoConfig(name=name, path=str(path), revisions=[rev, previous], include=["*.py", "CHANGES*"])
            index_repository(cfg, gname)
        q = RepoQuery(gname, name)
        sha, gap = q.resolve(rev)
        assert sha and not gap
        short = alias.rsplit(".", 1)[-1]
        candidates = [s for s in q.symbols(rev, short, limit=200).items
                      if s.qualname == alias or s.qualname.endswith("." + alias)]
        assert len(candidates) == 1, [s.qualname for s in candidates]
        symbol = candidates[0].qualname
        row = {"repo": name, "revision": rev, "sha": sha, "symbol": symbol,
               "graph": gname, "queries": [], "citation_checks": []}
        out["repositories"].append(row)
        original = q._q

        def trace(cypher, params=None):
            started = time.perf_counter()
            rows = original(cypher, params)
            row["queries"].append({"id": hashlib.sha256(cypher.encode()).hexdigest(),
                "cypher": cypher, "parameters": params, "rows": rows, "row_count": len(rows),
                "seconds": time.perf_counter() - started})
            return rows

        q._q = trace
        row["import_runs"] = q._q("MATCH (r:ImportRun {status:'COMPLETE'})-[:INDEXED]->(:Commit {sha:$s}) "
                                   "RETURN r.id,r.status", {"s": sha})
        page = q.dependencies(rev, symbol, hops=3, limit=200)
        row["dependencies"] = asdict(page)
        row["history"] = [asdict(x) for x in q.symbol_history(symbol, [previous, rev])]
        assert any(x.hops >= 2 for x in page.items), "selected probe must retrieve at least two hops"
        for edge in page.items:
            for cite in [edge.citation, edge.target_citation]:
                if not cite:
                    continue
                p = subprocess.run(["git", "--git-dir=" + str(path), "show", f"{cite.commit}:{cite.path}"],
                                   capture_output=True, text=True, check=True)
                valid = cite.repo == name and cite.commit == sha and 1 <= cite.start_line <= cite.end_line <= len(p.stdout.splitlines())
                row["citation_checks"].append({"citation": asdict(cite), "valid": valid})
        assert all(x["valid"] for x in row["citation_checks"])
        candidate = next(x for x in page.items if not x.external)
        # Stored identities can use the blob's old path; match both src layouts.
        src, target = candidate.source.removeprefix("src."), candidate.target.removeprefix("src.")
        db.select_graph(gname).query(
            f"MATCH (s:Symbol)-[e:{candidate.kind}]->(t:Symbol) "
            "WHERE (s.qualname=$s OR s.qualname=$sp) AND (t.qualname=$t OR t.qualname=$tp) DELETE e",
            {"s": src, "sp": "src."+src, "t": target, "tp": "src."+target})
        fresh = RepoQuery(gname, name).dependencies(rev, symbol, hops=3, limit=200)
        row["ablation"] = {"removed_edge": asdict(candidate), "before": len(page.items),
                            "after": asdict(fresh), "conclusion_changed": len(fresh.items) < len(page.items)}
        assert row["ablation"]["conclusion_changed"]
        db.select_graph(gname).query("MATCH (r:ImportRun) SET r.status='FAILED'")
        stale = RepoQuery(gname, name).symbols(rev)
        row["stale_import"] = asdict(stale)
        assert any(g.kind == "INCOMPLETE_IMPORT" for g in stale.coverage.get("gaps", []))
        print(name, "real multi-hop edges", len(page.items), "after ablation", len(fresh.items), flush=True)
        dest.write_text(json.dumps(out, indent=2, default=str))
except BaseException as exc:
    out["errors"].append({"type": type(exc).__name__, "message": str(exc)})
    raise
finally:
    dest.write_text(json.dumps(out, indent=2, default=str))
    # Both are audit-owned disposable graphs; do not touch user graphs.
    for name in [scratch, "audit_scale_goal_02"]:
        try:
            db.select_graph(name).delete()
        except Exception:
            pass
