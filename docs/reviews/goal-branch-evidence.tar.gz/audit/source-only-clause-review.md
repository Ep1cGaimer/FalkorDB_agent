# Clause review of the full v1 requirements

Commit `d7cf693`; authority: `/Users/vinay2047/Documents/github/FalkorDB_agent/remquirements-v1.md` (134 lines). Source-only review. Partial = incomplete proof; missing evidence ≠ missing code. No complete T gate established.

Keys: repository-relative files; :N = line.

| Key | Source |
|---|---|
| I / Q / V / P / R | `src/rw/repo/index.py` / `query.py` / `investigate.py` / `adapters/python.py` / `runtime.py` |
| H / C / B / Z | `evals/repo_history_eval.py` / `repo_eval_common.py` / `repo_benefit.py` / `repo_scale.py` |
| D / U | `evals/repo_benefit_threshold.json` / `repo_budgets.json` |
| A / F / J / K | `tests/repo/test_e1_onboarding.py` / `test_s4_scale.py` / `test_s5_access.py` / `test_s6_boundaries.py` |
| X / O / S | `tests/repo/test_e5_reproducibility.py` / `evals/repo_onboarding/README.md` / `docs/REPO_STATUS.md` |

## Every T clause

L = spec line; all bullets included.

| Clause | Assessment and current evidence |
|---|---|
| T0.1 / L32 | Conflict/partial. D freezes some settings. H:41–60 executes oracle retrieval plans; B:374–393 selects files from expected citations. No signed full contract. |
| T0.2 / L33 | Partial. U: 1800s import/120s update/2048MB memory/2000ms p95/50 rows/1024MB index/zero failures; D:7500 tokens/eight calls/six turns. Timeout/demo/spend/environment incomplete. |
| T0.3 / L34 | Partial. Two real configs and unseen hashes exist (O:11–34). Z:134–150 uses bytes/4, without actual tokenizer or output/tool reserve. Runs untracked. |
| T0.4 / L35 | Missing. No signed timestamped full-plan/corpus manifest. |
| T1.1 / L39 | Partial. A:59–87 implements onboarding/freeze checks; O:27–29 records config field counts rather than elapsed setup effort. Receipts untracked. |
| T1.2 / L40 | Partial. Synthetic isolation/non-execution: `test_s1_integration.py:273–320`. Parse/unsupported gaps: P:49–51/I:197–199. Q:317–331 omits them; path matrix execution unverified. |
| T1.3 / L41 | Partial. Existing acceptance-oracle, SQL and live tests remain. J:323–325 silently returns without MCP package; no full published eight-case/live report. |
| T1.4 / L42 | Missing. Configs/isolation tests exist; S:17 receipts untracked; full conjunction unproved. |
| T2.1 / L46 | Conflict. Initial real suite 11+11; rounds 2/3 add 20 each: at most 62 real questions across changing suites. Required ≥120, ≥20 per six strata, ≥40 complex; no power analysis. |
| T2.2 / L47 | Partial. Oracle facts/spans and synthetic backports exist. Four initial real negatives; no ≥30 complete negative oracles. |
| T2.3 / L48 | Conflict. C:157–161 scores span overlap; C:193–206 accepts keywords plus recall >0, without rejecting unsupported extra conclusions or invalid positive citations. |
| T2.4 / L49 | Conflict. H:164–166 drops exceptions. C:161 empty precision=None; B:598–609/H:109–120 exclude None. Missing required zero scores/question-first macro accounting. |
| T2.5 / L50 | Conflict. H:32/D declare two repeats, below ≥3. B:818–820 shuffles arms. No ≥25% blind double-score/agreement record. |
| T2.6 / L51 | Unproven. Require overall ≥90%, each repo/stratum ≥85%, precision ≥95%, recall ≥90%, citations 100%, zero critical errors; all negatives honest. S:19 admits wrong-revision flags. |
| T3.1 / L55 | Partial. `test_s3_revisions.py:111–274` covers merge/revert/reapply/overwrite/backport/rename/deletion. Full independent DAG oracle absent. |
| T3.2 / L56 | Conflict/partial. I:152–154 appends moved-tag targets; Q:216–218 picks first. I:167–225/P:53–78/Q:279 binds identical-content relative imports to first path. |
| T3.3 / L57 | Missing. No ≥100 seeded histories/invariants/seed ledger/minimized failures; fixed cases exist. |
| T3.4 / L58 | Unproven. Required 100% deterministic agreement/zero ancestry-only false presence plus T2. Subset tested; T2 unmet. |
| T4.1 / L62 | Conflict/partial. F:307–389 tests reuse/invalidation/version changes. I:140–142 skips existing maps despite changed config. Full normalized equivalence absent. |
| T4.2 / L63 | Partial. I:219–221 blob-count fault hook; F:390–428/Z:362–400 retry. Missing every persistence/discovery/publication boundary, seeded random/process-restart/prior-snapshot matrix. |
| T4.3 / L64 | Conflict. No lock/rejection; I:335–354 replaces shared symbols while Q:207–209 trusts old COMPLETE imports, exposing mixed/partial generations. |
| T4.4 / L65 | Unproven. F:390 onward/Z:388–392 compare counts, not every entity/relation/provenance/coverage/answer or every fault and duplicate/recovery-time requirement. |
| T5.1 / L69 | Partial. F:177–223 tests pagination/limits/bad cursors; F:273 traversal bounds. Missing complete 0/1/cap−1/cap/cap+1 × hops/cycles/final-page/expiry oracle matrix. |
| T5.2 / L70 | Conflict. Q:103–118 cursor is only offset o:N, without repo/revision/query/generation binding. Q:388 exposes edge gaps; time/token/stale-page contract incomplete. |
| T5.3 / L71 | Unproven. Selected enumeration tests exist; identity cursors fail, and Q:534–540 infers absence without extraction-coverage checks. |
| T6.1 / L75 | Partial. Z:292–344 measures one requests corpus; Z:134–150 approximate bytes/history tokens. Missing full corpus plus ≥2 smaller slices and depth/fan-out distributions. |
| T6.2 / L76 | Conflict. Z:327–328 one import/update; Z:214–242 one fixed workload. Missing ≥3 cold/≥3 updates per slice, ≥100 queries/slice, warmup/concurrency/actual-cost protocol. |
| T6.3 / L77 | Unproven. Z:412–421 checks selected budgets. Require ≥99% timely valid success, T2/T5 quality at scale. S:20 reports 6/7 budgets and one failure; raw run untracked. |
| T7.1 / L81 | Partial. J:296–313 compares four cases and limited summary fields. Full pinned-generation matrix absent. |
| T7.2 / L82 | Partial. J:402–414 checks bad names/required fields. Timeout/cancel/oversize/retry/restart/parallel/follow-up selection evidence incomplete. |
| T7.3 / L83 | Missing. J:312 invokes Python MCP wrapper; J:316–331 registration is not transport. No real MCP transcript/100% agreement proof. |
| T8.1 / L87 | Partial. K:198–247 checks hostile source/subprocess allowlist. Full symlink/instruction/effects audit absent. |
| T8.2 / L88 | Mechanism present. V:189–211 explicit adapter; R:38–49 receipt gates; K:108–195 boundary tests. No default adapters/non-fixture isolation proof. |
| T8.3 / L89 | Partial. R:33–49 checks revision/extractor/adapter and failure precedence; fixture approval/simulation tests remain. Full obligation/identity matrix unproved. |
| T8.4 / L90 | Unproven. Require zero executions/effects/false passes and 100% deterministic receipts. Full threat-model audit traces and reports untracked. |
| T9.1 / L94 | Partial. Q:177–178 real DB call; H:53–54/B:593 tool traces. Full query-to-answer chain absent. |
| T9.2 / L95 | Missing. No controlled edge-removal/stale-record/interrupted-retrieval ablation suite/results. V:141–144 DB error handling is not causal contribution testing. |
| T9.3 / L96 | Unproven. Required ablations and reproducible necessary multi-hop evidence on each real repo absent; actual graph query mechanism exists. |
| T10.1 / L100 | Partial. B:320–393 implements practical Git search and direct context; direct files chosen using oracle spans. SQL tie acknowledged (S:33). |
| T10.2 / L101 | Partial. Shared prompt/model/shuffled order B:94–104,818–820. Only two repeats; B:161–182,585 loses earlier retry duration in latency. Full fair run absent. |
| T10.3 / L102 | Conflict. B:643–649 allows either +15pp/±20% total tokens or −30% total tokens/−5pp quality. Required exactly one A:+10pp,input/cost≤+5%; B:input−20%,no quality loss. |
| T10.4 / L103 | Missing. No ≥10,000 stratified paired bootstraps/95% CIs. Require A gain lower>0; B token-ratio upper≤.80 and quality-difference lower≥0. |
| T10.5 / L104 | Conflict/unproven. B:652–675 pooled stronger-baseline verdict lacks each-comparator/repo veto, T2 safety/CIs/break-even. S:28 correctly withholds advantage. |
| T11.1 / L108 | Missing. Commands documented; referenced repo artifacts untracked. X:45–48 skips absent categories; X:69–95 validates field shapes, not full bundle/recomputation. |
| T11.2 / L109 | Missing. No clean independent score/CI reproduction or fresh ≥12-question both-repo/six-strata live run. |
| T11.3 / L110 | Missing. No three reset demos with scenes/fresh questions/timings/failures. |
| T11.4 / L111 | Missing. No linked claim card, budget-compliant demos or official deliverable check. |

## Status and ledger clauses

| Spec line | Assessment and evidence |
|---|---|
| 20–21 | S:14–28 separates scope/status, but S:17–22 prematurely validates S1/S3/S5/S6. Full applicable gates are unmet. |
| 22 | S:28,33 withholds advantage/preserves SQL tie. Round manifests exist; complete original runs and independent version freezes untracked. |
| 23 | Coverage contradicted: I records errors, Q:317–331 omits them; Q:539–540/V:245 convert missing symbols to absence. |
| 24 | R:38–49 implements receipt precedence; I/Q lack generation-safe invalidation of current evidence/claims. |
| 115–126 | Every listed gate mandatory; implementation tests do not substitute for evaluations/reproduction. S/E validation unproved. |
| 130 | Machine-readable ledger absent: requirement/test IDs, status/owner, implementation/plan/corpus hashes, runs/artifacts, metrics/thresholds, failures, limitations, reviewer/time; blocked needs obstacle/action. S is prose. |
| 131 | Missing artifact/required skip/incomplete or inconclusive run prevents validation; S5 validated despite admitted absent MCP integration. Failed corrective work alone is IN_PROGRESS. |
| 132 | S1/S3/S5/S6 release claims premature; advantage correctly withheld.  |
| 133 | Round sets show iteration; no complete hash-linked historical/current invalidation ledger or independently fresh confirmatory holdouts. |
| 134 | Partial per-repo metrics, missing complete denominators/strata/variation/CIs/costs/reproduction links. No broad claim found. |

Astronomy fixture/UI work is ancillary scope.
