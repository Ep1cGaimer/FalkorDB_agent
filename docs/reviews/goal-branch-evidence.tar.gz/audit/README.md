# Fresh audit evidence

Authoritative implementation: d7cf693e26073c825f0b6a2bd741ce5d05752f72.
Authoritative spec: audit/requirements-source.md (copied from the user's full local file).
All scored results were generated anew during this audit. No archived pre-audit score is accepted.

The archive preserves paths relative to the reviewed checkout. Extract into a clean checkout at
the implementation commit. The directly readable evidence directory flattens audit files and
renames .log to .txt; use the archive layout to run scripts unchanged.

Environment: Python >=3.12, pyproject.toml pinned dependencies plus pytest and mcp==2.3.0;
local FalkorDB module60002/Redis8.10.2, port6379, RESULTSET_SIZE10000. See database-environment.json.
The audit reused /private/tmp/rw-mcp-compat/bin/python with the recorded dependency versions.

Fresh commands (PY denotes that installed Python; run from the checkout root):

    PY -m pytest -q -m 'not live and not realrepo' --junitxml=audit/branch-suite.xml
    git clone --bare https://github.com/psf/requests.git artifacts/repos/requests
    git clone --bare https://github.com/pallets/itsdangerous.git artifacts/repos/itsdangerous
    git clone --bare https://github.com/pallets/markupsafe.git artifacts/repos/markupsafe
    RW_REALREPO=1 PY -m pytest -q tests/repo/test_e1_onboarding.py tests/repo/test_e2_e4_protocol.py::test_citations_resolve_in_clone
    PY -m pytest -q audit/test_adversarial_review.py audit/test_extra_review.py
    PY -m pytest -q audit/test_generated_histories.py
    PY -m pytest -q audit/test_ingestion_canaries.py
    PY -m pytest -q audit/test_pagination_boundaries.py
    PY scripts/smoke.py
    node --test tests/js/*.test.mjs
    PY evals/repo_scale.py --graph audit_scale_goal_01
    PY evals/repo_scale.py --graph audit_scale_goal_02
    PY evals/repo_scale.py --graph audit_scale_goal_03
    PY audit/run_surfaces_and_graph.py
    PY audit/run_graph_probes.py

run_graph_probes consumes the audit-owned scale02 graph; run it after scale02 has finished.
Do not give these harnesses names of graphs containing other work. Harnesses delete disposable graphs.
run_surfaces_and_graph.py preserves an earlier alias-lookup setup error; exact graph proof is in
run_graph_probes.py. run_surfaces_and_graph_v2.py is a retained failed setup attempt, not a required
passing replay. These attempts and the original canary source are retained honestly.

Live fixture tests were run with local credentials loaded privately using rw.config.load_env,
then pytest.main(['-q','-s','-m','live','tests','--junitxml=audit/fresh-live-fixture.xml']).
Supply your own provider account/keys. Never copy credentials into this bundle. Live outputs vary.
For future live runs, set --basetemp=audit/live-pytest-temp and copy transcripts before other pytest
runs rotate temporary folders. The first flat-control raw transcript was lost to that rotation;
its printed result/probes/failure and JUnit remain, while two grounding raw transcripts were retained.
No all-arm live repository advantage evaluation was performed or claimed.

Expected red tests assert required correct behavior; failures demonstrate the reviewed defects.
The extra pagination depth-warning assertion is overstrict for explicitly scoped hops and excluded
from defect counts. First no-DB attempt and first wrong-name base test are setup failures, retained.
The baseline successful schema test used f189d7c1a38e3648cd28b977050822c95d8c7597 and the then-current
test name test_six_tools_schemas_output_refs_annotations_and_parity.

All fixture oracle A-H and identity cases I-J were rerun. Current source core hashes are in
surfaces-and-graph.json. The full T0–T11 experiments are incomplete; the bundle does not certify them.
