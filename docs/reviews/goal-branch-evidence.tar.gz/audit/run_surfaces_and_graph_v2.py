"""Fresh config-only onboarding, real stdio MCP, and causal graph probes.

This audit harness does not replace or fix product source. No expected answers
are supplied to ingestion or investigation. All created graphs are disposable.
"""
import asyncio
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from rw import graph as G
from rw.repo.config import RepoConfig
from rw.repo.index import index_repository, graph_name_for
from rw.repo.investigate import investigate
from rw.repo.query import RepoQuery

OUT = ROOT / "audit" / "surfaces-and-graph-v2.json"
CONFIGS = ROOT / "audit" / "fresh-configs-v2"
CONFIGS.mkdir(exist_ok=True)
os.environ["RW_REPOS_DIR"] = str(CONFIGS)


def core_hashes():
    return {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ROOT / "src/rw").rglob("*.py"))}


def git(repo, *args):
    return subprocess.run(["git", "--git-dir=" + str(repo), *args],
                          capture_output=True, text=True, check=True).stdout


async def main():
    from fastapi.testclient import TestClient
    from rw.api import create_app
    from mcp import ClientSession
    from mcp.client.stdio import StdioServerParameters, stdio_client

    token = uuid.uuid4().hex[:8]
    db = G.connect()
    record = {"scope": "fresh audit subset; not the full T1/T7/T9 gates",
              "core_before": core_hashes(), "repositories": [], "transports": [], "errors": []}
    graphs = []
    try:
        for repo, revision, symbol in [
            ("requests", "v2.32.0", "requests.api.get"),
            ("itsdangerous", "2.2.0", "itsdangerous.serializer.Serializer.dumps"),
            ("markupsafe", "HEAD", None),
        ]:
            name = f"audit-{repo}-{token}"
            path = ROOT / "artifacts/repos" / repo
            cfg = RepoConfig(name=name, path=str(path), revisions=[revision],
                             include=["*.py", "*.pyi", "CHANGES*", "HISTORY*"], languages=["python"])
            (CONFIGS / f"{name}.json").write_text(cfg.model_dump_json(indent=2))
            gname = graph_name_for(cfg)
            graphs.append(gname)
            started = time.perf_counter()
            report = index_repository(cfg)
            q = RepoQuery(gname, name)
            sha, gap = q.resolve(revision)
            row = {"name": name, "upstream": repo, "config": cfg.model_dump(),
                   "index": asdict(report), "setup_seconds": time.perf_counter() - started,
                   "revision": revision, "sha": sha, "selected_symbol": symbol,
                   "graph_traces": [], "ablations": []}
            record["repositories"].append(row)
            OUT.write_text(json.dumps(record, indent=2, default=str))
            print("INDEX", repo, report.status, report.commits, flush=True)
            if symbol:
                original = q._q

                def traced(cypher, params=None):
                    t = time.perf_counter()
                    rows = original(cypher, params)
                    row["graph_traces"].append({"query": cypher, "parameters": params,
                      "rows": rows, "row_count": len(rows), "seconds": time.perf_counter() - t,
                      "repository": name, "revision": sha, "import_run": report.import_run_id})
                    return rows

                q._q = traced
                candidates = q.symbols(revision, name=symbol, limit=200).items
                assert len(candidates) == 1, [(s.qualname,s.path) for s in candidates]
                symbol = candidates[0].qualname
                row["resolved_symbol"] = symbol
                page = q.dependencies(revision, symbol, hops=3, limit=200)
                previous = "v2.31.0" if repo == "requests" else "2.1.0"
                row["history"] = [asdict(x) for x in q.symbol_history(symbol, [previous, revision])]
                row["multi_hop"] = asdict(page)
                row["citation_checks"] = []
                for edge in page.items:
                    for cite in [edge.citation, edge.target_citation]:
                        if cite:
                            text = git(path, "show", f"{cite.commit}:{cite.path}")
                            row["citation_checks"].append({"citation": asdict(cite),
                                "valid": cite.repo == name and cite.commit == sha and
                                 1 <= cite.start_line <= cite.end_line <= max(1, len(text.splitlines()))})
                # Remove all CALLS/IMPORTS/INHERITS edges on this disposable graph.
                before = [asdict(x) for x in page.items]
                candidate = next((x for x in page.items if not x.external), None)
                assert candidate is not None, "audit question must retrieve an internal dependency edge"
                kind = candidate.kind
                assert kind in {"CALLS", "IMPORTS", "INHERITS"}
                # Target the stored source by its rebased suffix (src. is a layout prefix).
                source = candidate.source.removeprefix("src.")
                target = candidate.target.removeprefix("src.")
                db.select_graph(gname).query(
                    f"MATCH (s:Symbol)-[e:{kind}]->(t:Symbol) "
                    "WHERE (s.qualname=$s OR s.qualname=$sp) AND (t.qualname=$t OR t.qualname=$tp) DELETE e",
                    {"s":source,"sp":"src."+source,"t":target,"tp":"src."+target})
                row["removed_edge"] = asdict(candidate)
                ablated = RepoQuery(gname, name).dependencies(revision, symbol, hops=3, limit=200)
                row["ablations"].append({"operation": "remove dependency edges", "before": before,
                    "after": asdict(ablated), "supported_conclusion_lost": bool(before) and len(ablated.items) < len(before)})
                # Rebuild disposable graph; then verify publication stale marker is respected.
                db.select_graph(gname).delete()
                report = index_repository(cfg)
                db.select_graph(gname).query("MATCH (r:ImportRun) SET r.status='FAILED'")
                stale = RepoQuery(gname, name).symbols(revision)
                row["ablations"].append({"operation": "invalidate completed import", "after": asdict(stale),
                    "gap_exposed": any(g.kind == "INCOMPLETE_IMPORT" for g in stale.coverage.get("gaps", []))})
                db.select_graph(gname).query("MATCH (r:ImportRun) SET r.status='COMPLETE'")
            OUT.write_text(json.dumps(record, indent=2, default=str))

        client = TestClient(create_app(session_factory=lambda *a, **k: None))
        params = StdioServerParameters(command=sys.executable, args=[str(ROOT / "scripts/serve_mcp.py")],
                 cwd=ROOT, env={**os.environ, "RW_REPOS_DIR": str(CONFIGS)})
        with (ROOT / "audit/mcp-stderr-v2.log").open("w") as stderr:
            async with stdio_client(params, errlog=stderr) as (read, write):
                async with ClientSession(read, write, read_timeout_seconds=30) as session:
                    await session.discover()
                    record["mcp_tools"] = [x.model_dump(mode="json", by_alias=True)
                                             for x in (await session.list_tools()).tools]
                    cases = []
                    for row in record["repositories"][:2]:
                        cases.extend([(row["name"], row["revision"], "List symbols"),
                                      (row["name"], "missing-audit-revision", "List symbols"),
                                      (row["name"], row["revision"], "Where is missing_audit_symbol defined?"),
                                      (row["name"], row["revision"], "Write an unsupported poem")])
                    cases.append(("missing-audit-repository", "HEAD", "List symbols"))
                    for name, rev, question in cases:
                        args = {"repo": name, "revision": rev, "question": question}
                        direct = investigate(name, rev, question).to_dict()
                        api = client.post(f"/api/repos/{name}/investigate",
                                          json={"revision": rev, "question": question})
                        proc = subprocess.run([sys.executable, str(ROOT / "scripts/repo_investigate.py"),
                                "--repo", name, "--rev", rev, question], cwd=ROOT,
                                env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
                                capture_output=True, text=True, timeout=30)
                        result = await session.call_tool("repo_investigate", args)
                        mcp = result.structured_content
                        # Unstructured dict-return MCP tools may supply only JSON text.
                        if mcp is None and not result.is_error:
                            mcp = json.loads(result.content[0].text)
                        cli = json.loads(proc.stdout) if proc.returncode == 0 else None
                        result_row = {"request": args, "direct": direct, "cli_exit": proc.returncode,
                            "cli": cli, "api_status": api.status_code, "api": api.json(),
                            "mcp": result.model_dump(mode="json", by_alias=True),
                            "exact_semantic_parity": cli == direct == api.json() == mcp}
                        record["transports"].append(result_row)
                        print("SURFACE", name, rev, question, result_row["exact_semantic_parity"], flush=True)
                        OUT.write_text(json.dumps(record, indent=2, default=str))
                    # These are malformed/oversized contract probes, not model requests.
                    for args in [{"repo": record["repositories"][0]["name"], "revision": "v2.32.0", "question": ""},
                                 {"repo": record["repositories"][0]["name"], "revision": "v2.32.0", "question": "x" * 2001},
                                 {"repo": "../outside", "revision": "HEAD", "question": "List symbols"}]:
                        api = client.post(f"/api/repos/{args['repo']}/investigate",
                                          json={k: args[k] for k in ["revision", "question"]})
                        result = await session.call_tool("repo_investigate", args)
                        record["transports"].append({"invalid_input": args, "api_status": api.status_code,
                            "api": api.json(), "mcp": result.model_dump(mode="json", by_alias=True)})
    except BaseException as exc:
        record["errors"].append({"type": type(exc).__name__, "message": str(exc)})
        raise
    finally:
        record["core_after"] = core_hashes()
        record["core_unchanged"] = record["core_before"] == record["core_after"]
        OUT.write_text(json.dumps(record, indent=2, default=str))
        for name in graphs:
            try:
                db.select_graph(name).delete()
            except Exception:
                pass


if __name__ == "__main__":
    asyncio.run(main())
