"""Development run orchestration, evidence locking and honest failures, using fakes."""
import copy
import hashlib
import importlib
import json
from pathlib import Path

import pytest


@pytest.fixture
def modules(monkeypatch):
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "evals"))
    return (importlib.import_module("confirmatory.investigation_runner"),
            importlib.import_module("confirmatory.gemini_meter"))


TASK = {"id": "DEV-ONLY", "repository": "synthetic-development", "revision": "a" * 40,
        "question": "What is the literal returned by example?"}
FINAL = {"answer": "The literal is 1.", "citations": [{"repository": TASK["repository"],
    "commit": "a" * 40, "path": "example.py", "start_line": 1, "end_line": 2}],
    "gaps": ["runtime unverified"], "runtime_disposition": None}


class ScriptedAPI:
    model = "models/fake-development"
    def __init__(self, directory, actions=None):
        self.directory, self.requests = directory, []
        self.actions = actions or [{"action": "call", "name": "read", "arguments": {}},
                                   {"action": "finish"}, FINAL]
    def count(self, request, timeout):
        return {"totalTokens": 100}
    def generate(self, request, timeout):
        self.requests.append(copy.deepcopy(request))
        if request["systemInstruction"]["parts"][0]["text"].startswith("Answer the supplied repository/history question"):
            assert (self.directory / "retrieval.json").exists(), "evidence must lock before answer"
        value = self.actions[len(self.requests) - 1]
        text = value if isinstance(value, str) else json.dumps(value)
        return {"modelVersion": "fake-v1", "usageMetadata": {"promptTokenCount": 100,
            "candidatesTokenCount": 20, "thoughtsTokenCount": 5, "totalTokenCount": 125},
            "candidates": [{"finishReason": "STOP", "content": {"role": "model", "parts": [{"text": text}]}}]}


def setup(modules, tmp_path, actions=None, limits=None):
    runner, meter = modules
    directory = tmp_path / "attempt"
    api = ScriptedAPI(directory, actions)
    model = meter.MeteredModel(api, meter.Journal(directory), limits or meter.ModelLimits())
    return runner, model, api


def run(runner, model, *, capabilities=None, descriptions=None, **kwargs):
    return runner.run_development_question(TASK, capabilities or {"read": lambda: {"content": "return 1"}},
        descriptions or {"read": {"description": "Read synthetic source", "arguments": {}}}, model, **kwargs)


def test_evidence_is_durably_locked_before_final_generation_and_result_is_unscored(modules, tmp_path):
    runner, model, api = setup(modules, tmp_path)
    result = run(runner, model)
    assert result["status"] == "COMPLETE_UNSCORED" and not result["acceptance_validated"]
    assert result["answer"] == FINAL
    assert result["model_usage"]["reported_input_tokens"] == 300
    assert result["model_usage"]["reported_output_including_thinking"] == 75
    directory = tmp_path / "attempt"
    assert result["retrieval_sha256"] == hashlib.sha256((directory / "retrieval.json").read_bytes()).hexdigest()
    assert result["events_sha256"] == hashlib.sha256((directory / "events.jsonl").read_bytes()).hexdigest()
    events = [json.loads(x) for x in (directory / "events.jsonl").read_text().splitlines()]
    locked = next(e["sequence"] for e in events if e["kind"] == "retrieval_locked")
    final = next(e["sequence"] for e in events if e["kind"] == "generation_started" and e["phase"] == "answer")
    assert locked < final
    assert "elapsed_seconds" not in api.requests[-1]["contents"][0]["parts"][0]["text"]


def test_same_answer_instruction_for_different_retrieval_capabilities(modules, tmp_path):
    runner, meter = modules
    prompts = []
    for index, name in enumerate(["plain_read", "graph_read"]):
        directory = tmp_path / str(index)
        actions = [{"action": "call", "name": name, "arguments": {}}, {"action": "finish"}, FINAL]
        api = ScriptedAPI(directory, actions)
        model = meter.MeteredModel(api, meter.Journal(directory))
        runner.run_development_question(TASK, {name: lambda: {"source": "same raw corpus"}},
                                        {name: {"description": "arm-specific retrieval interface"}}, model)
        prompts.append(api.requests[-1]["systemInstruction"])
    assert prompts[0] == prompts[1]


@pytest.mark.parametrize("decision", ['{"action":"finish","action":"call"}',
    '{"action":"finish","bad":NaN}', '{"action":"call","name":"read"}', '["finish"]'])
def test_malformed_planner_output_remains_a_failed_attempt(modules, tmp_path, decision):
    runner, model, api = setup(modules, tmp_path, [decision])
    result = run(runner, model)
    assert result["status"] == "ERROR" and result["answer"] is None
    assert result["model_usage"]["calls"] == 1 and len(api.requests) == 1
    assert (tmp_path / "attempt/result.json").exists()


def test_tool_budget_exhaustion_prevents_unsupported_final_answer(modules, tmp_path):
    runner, model, api = setup(modules, tmp_path)
    budget = importlib.import_module("confirmatory.tool_budget")
    result = run(runner, model, capabilities={"read": lambda: "x" * 10000},
                 tool_limits=budget.ToolLimits(output_bytes=100))
    assert result["failure"] == "RETRIEVAL_BUDGET_EXHAUSTED" and result["answer"] is None
    assert len(api.requests) == 1 and result["tool_usage"]["exhausted"] == "output_bytes"


def test_model_budget_after_retrieval_preserves_lock_and_fails_case(modules, tmp_path):
    runner, meter = modules
    runner, model, api = setup(modules, tmp_path, limits=meter.ModelLimits(calls=2))
    result = run(runner, model)
    assert result["failure"] == "MODEL_CALL_BUDGET_EXHAUSTED" and result["answer"] is None
    assert result["retrieval_sha256"] and len(api.requests) == 2


def test_source_only_runtime_pass_is_rejected_without_discarding_generation(modules, tmp_path):
    bad = {**FINAL, "runtime_disposition": "BOUNDED_PASS"}
    runner, model, api = setup(modules, tmp_path, [{"action": "finish"}, bad])
    result = run(runner, model)
    assert result["failure"] == "UNSUPPORTED_RUNTIME_DISPOSITION" and result["answer"] is None
    assert result["model_usage"]["calls"] == 2


def test_expected_answers_and_confirmatory_ids_cannot_enter_development_runner(modules):
    runner, _ = modules
    with pytest.raises(ValueError, match="scoring"):
        runner.public_task({**TASK, "expected_answer": "secret oracle"})
    with pytest.raises(ValueError, match="confirmatory"):
        runner.public_task({**TASK, "id": "CF-REQ-DEP-01"})


def test_persisted_failed_tool_can_be_followed_by_explicit_recovery(modules, tmp_path):
    actions = [{"action": "call", "name": "missing", "arguments": {}},
               {"action": "call", "name": "read", "arguments": {}}, {"action": "finish"}, FINAL]
    runner, model, api = setup(modules, tmp_path, actions)
    result = run(runner, model)
    assert result["status"] == "COMPLETE_UNSCORED"
    trace = json.loads((tmp_path / "attempt/retrieval.json").read_text())["tool_trace"]
    assert [t["response"]["status"] for t in trace] == ["ERROR", "OK"]
    assert result["tool_usage"]["used"]["tool_calls"] == 2
