"""Three-commit, one-file reduction of the exact-presence/UNCERTAIN mismatch."""
import dataclasses,hashlib,json,subprocess
from pathlib import Path
from rw import graph as G
from rw.repo.config import RepoConfig
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
out=Path(__file__).resolve().parent
repo=out/'reduced-regression';repo.mkdir()
commands=[]
def git(*args):
    cmd=['git','-c','user.name=Independent reduction','-c','user.email=reduce@example.invalid','-c','commit.gpgsign=false','-C',str(repo),*args]
    r=subprocess.run(cmd,capture_output=True,text=True,check=True);commands.append({'argv':cmd,'stdout':r.stdout,'stderr':r.stderr});return r.stdout.strip()
git('init','-q','-b','main');states={};labels={}
for label,value in [('base','base-a'),('fix','fixed-a'),('overwrite','feature-a')]:
    content=f'def parse():\n    return {value!r}\n';(repo/'a.py').write_text(content)
    git('add','a.py');git('commit','-qm',label);s=git('rev-parse','HEAD');states[s]={'a.py':content};labels[label]=s
oracle={'states':states,'labels':labels,'expected_overwrite_fix_status':'ABSENT','meaning':'exact added return line no longer exists; semantic equivalence is not asserted'}
(out/'reduced-expected.json').write_text(json.dumps(oracle,indent=2)+'\n')
db=G.connect(port=57955);cfg=RepoConfig(name='independent-reduced',path=str(repo),revisions=['HEAD']);trace=[]
try:
    receipt=index_repository(cfg,'history_matrix_reduced',db=db)
    status=RepoQuery('history_matrix_reduced',cfg.name,db=db,trace=trace).fix_status(labels['overwrite'],labels['fix'])
    record={'expected':oracle,'actual':dataclasses.asdict(status),'trace':trace,'import':dataclasses.asdict(receipt),'git_commands':commands,'reproduces_original_mismatch':status.state=='UNCERTAIN'}
    (out/'reduced-results.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'actual':status.state,'reproduces':record['reproduces_original_mismatch']}))
finally:db.select_graph('history_matrix_reduced').delete()
