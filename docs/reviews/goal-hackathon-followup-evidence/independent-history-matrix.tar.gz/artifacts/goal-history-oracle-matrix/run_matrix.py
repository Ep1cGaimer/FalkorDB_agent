"""Additional predeclared, independently authored DAG/identity probe. No product changes."""
import dataclasses,hashlib,json,os,subprocess,time,traceback
from pathlib import Path
from rw import graph as G
from rw.repo.config import RepoConfig
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
from rw.repo.investigate import investigate
OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[1]
OUT.mkdir(parents=True,exist_ok=True)
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True,default=str)+"\n")
def sha(data):return hashlib.sha256(data).hexdigest()
def source_pin():return {str(p.relative_to(ROOT)):sha(p.read_bytes()) for p in sorted((ROOT/'src').rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
def git(repo,*args,ok=True):
    cmd=['git','-c','user.name=Independent matrix oracle','-c','user.email=matrix@example.invalid','-c','commit.gpgsign=false','-c','tag.gpgsign=false','-C',str(repo),*args]
    r=subprocess.run(cmd,capture_output=True,text=True,env={**os.environ,'GIT_AUTHOR_DATE':'2026-01-02T00:00:00+0000','GIT_COMMITTER_DATE':'2026-01-02T00:00:00+0000'})
    with (OUT/'git-commands.jsonl').open('a') as log:log.write(json.dumps({'argv':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    if ok and r.returncode:raise RuntimeError(r.stderr)
    return r.stdout.strip() if ok else r.returncode
repo=OUT/'repository';repo.mkdir();git(repo,'init','-q','-b','main')
states={};labels={};parent_lists={};expected={}
def commit(label,files,parents,state):
    for p in repo.rglob('*'):
        if p.is_file() and '.git' not in p.relative_to(repo).parts and str(p.relative_to(repo)) not in files:p.unlink()
    for name,text in files.items():(repo/name).write_text(text)
    git(repo,'add','-A');git(repo,'commit','-qm',label)
    s=git(repo,'rev-parse','HEAD');states[s]=dict(files);labels[label]=s;parent_lists[s]=parents;expected[s]=state
    return s
def text(a,b):return f'def parse():\n    return {a!r}\n\ndef helper():\n    return {b!r}\n'
base_text=text('base-a','base-b');fixed=text('fixed-a','fixed-b')
predeclared={'expected':'Exact current presence of both changed return lines, not ancestry. Partial application is not full presence. Similar nonidentical nonancestor backport must remain UNCERTAIN. Rename/copy current-content checks may reveal ambiguity; failures are retained.',
 'matrix':['base','fix','partial revert','restore','divergent conflict','resolved two-parent merge','patch-identical cherry-pick','nonidentical backport','rename with edit','copy reused names','delete','recreate','missing revision','shallow clone','detached HEAD','introduced-at route']}
dump('predeclared.json',predeclared);before=source_pin();dump('source-before.json',before)
start=time.monotonic();result={'checks':[],'queries':[],'traces':[],'failures':[]}
def check(name,actual,want):
    row={'name':name,'actual':actual,'expected':want,'pass':actual==want};result['checks'].append(row)
    if not row['pass']:result['failures'].append(row)
db=G.connect(port=57955)
try:
    base=commit('base',{'a.py':base_text},[],'ABSENT');git(repo,'tag','t00-base',base)
    fix=commit('fix',{'a.py':fixed},[base],'PRESENT');git(repo,'tag','t01-fix',fix)
    partial=commit('partial',{'a.py':text('base-a','fixed-b')},[fix],'ABSENT')
    restored=commit('restored',{'a.py':fixed},[partial],'PRESENT')
    git(repo,'checkout','-qb','feature',restored)
    feature=commit('feature',{'a.py':text('feature-a','fixed-b')},[restored],'ABSENT')
    git(repo,'checkout','-q','main')
    mainchange=commit('mainchange',{'a.py':text('main-a','fixed-b')},[restored],'ABSENT')
    merge_rc=git(repo,'merge','--no-ff','feature','-m','expected conflict',ok=False)
    check('merge_produces_expected_conflict',merge_rc,1)
    merge=commit('merge-resolution',{'a.py':text('merged-a','fixed-b')},[mainchange,feature],'ABSENT')
    git(repo,'checkout','-qb','picked',base)
    precursor=commit('pick-precursor',{'a.py':base_text,'README.md':'different ancestry\n'},[base],'ABSENT')
    git(repo,'cherry-pick',fix)
    picked=git(repo,'rev-parse','HEAD');labels['picked']=picked;states[picked]={'a.py':fixed,'README.md':'different ancestry\n'};parent_lists[picked]=[precursor];expected[picked]='PRESENT'
    git(repo,'checkout','-qb','backport',base)
    backport=commit('backport',{'a.py':text('fixed-a-v2','fixed-b')},[base],'UNCERTAIN')
    git(repo,'checkout','-qb','renamed',fix)
    renamed=commit('renamed',{'renamed.py':fixed+'\n# edited during rename\n'},[fix],'PRESENT')
    copied=commit('copied',{'renamed.py':fixed+'\n# edited during rename\n','copy.py':fixed},[renamed],'PRESENT')
    deleted=commit('deleted',{'README.md':'all Python paths deleted\n'},[copied],'ABSENT')
    recreated=commit('recreated',{'a.py':base_text,'README.md':'all Python paths deleted\n'},[deleted],'ABSENT')
    git(repo,'tag','t02-deleted',deleted);git(repo,'checkout','-q','main')
    oracle={'states':states,'labels':labels,'parents':parent_lists,'fix_state':expected,'fix':fix}
    # Save a complete, immutable expected-state specification before indexing.
    dump('expected-state.json',oracle)
    for s,files in states.items():
        check('git-tree:'+s,git(repo,'ls-tree','-r','--name-only',s).splitlines(),sorted(files))
        headers=git(repo,'cat-file','-p',s).split('\n\n',1)[0].splitlines()
        check('git-parents:'+s,[x[7:] for x in headers if x.startswith('parent ')],parent_lists[s])
        for p,t in files.items():check('git-bytes:'+s+':'+p,git(repo,'show',f'{s}:{p}')+'\n',t)
    cfg=RepoConfig(name='independent-matrix',path=str(repo),revisions=list(labels.values()),tag_pattern='^t')
    result['import']=dataclasses.asdict(index_repository(cfg,'history_matrix',db=db))
    q=RepoQuery('history_matrix',cfg.name,db=db,trace=result['traces'])
    for label,s in labels.items():
        status=q.fix_status(s,fix)
        check('fix-status:'+label,status.state,expected[s])
        rows=q._q('MATCH (:Commit {sha:$s})-[f:HAS_FILE]->(b:Blob) RETURN f.path,b.content_hash ORDER BY f.path',{'s':s})
        check('indexed-files:'+label,rows,[[p,sha(t.encode())] for p,t in sorted(states[s].items())])
        parents=q._q('MATCH (:Commit {sha:$s})-[e:PARENT]->(p:Commit) RETURN p.sha ORDER BY e.order',{'s':s})
        check('indexed-parents:'+label,[x[0] for x in parents],parent_lists[s])
        # Ask the explicit introduced-at route and current-presence question at every state.
        intro=investigate(cfg.name,s,'When did a.parse appear',graph_name='history_matrix',db=db,config=cfg,trace=result['traces'])
        current=investigate(cfg.name,s,f'Is fix {fix} present',graph_name='history_matrix',db=db,config=cfg,trace=result['traces'])
        result['queries'].append({'label':label,'revision':s,'fix_status':dataclasses.asdict(status),'introduced_at':dataclasses.asdict(intro),'present_at':dataclasses.asdict(current),'symbol_history':[dataclasses.asdict(x) for x in q.symbol_history('a.parse',[s])]})
        if label not in ('renamed','copied','deleted'):
            histories=[f for f in intro.findings if f.kind=='symbol_history']
            check('introduced-first-tag:'+label,histories[0].facts.get('first_present_revision') if histories else None,'t00-base')
        if label=='picked':check('cherry-pick-equivalence-evidence','EQUIVALENT_BY_PATCH' in [g.kind for g in status.gaps],True)
        if label=='backport':check('backport-uncertainty-gap','BACKPORT_EQUIVALENCE_UNKNOWN' in [g.kind for g in status.gaps],True)
    result['missing']=dataclasses.asdict(q.fix_status('f'*40,fix));check('missing-revision-uncertain',result['missing']['state'],'UNCERTAIN')
    git(repo,'checkout','--detach',fix)
    detached_cfg=cfg.model_copy(update={'revisions':['HEAD'],'tag_pattern':None})
    index_repository(detached_cfg,'history_matrix_detached',db=db)
    check('detached-head-resolution',RepoQuery('history_matrix_detached',cfg.name,db=db).resolve('HEAD')[0],fix)
    shallow=OUT/'shallow';git(OUT,'clone','--depth','1','--branch','renamed',repo.as_uri(),str(shallow))
    shallow_cfg=RepoConfig(name='independent-shallow',path=str(shallow),revisions=['HEAD'])
    result['shallow_import']=dataclasses.asdict(index_repository(shallow_cfg,'history_matrix_shallow',db=db))
    sq=RepoQuery('history_matrix_shallow',shallow_cfg.name,db=db,trace=result['traces'])
    result['shallow_fix']=dataclasses.asdict(sq.fix_status('HEAD',fix))
    check('shallow-missing-fix-uncertain',result['shallow_fix']['state'],'UNCERTAIN')
except Exception:result['error']=traceback.format_exc()
finally:
    for graph in ('history_matrix','history_matrix_detached','history_matrix_shallow'):
        try:db.select_graph(graph).delete()
        except Exception as exc:result.setdefault('cleanup_errors',[]).append(str(exc))
    after=source_pin();dump('source-after.json',after);result['source_unchanged']=before==after
    result['seconds']=time.monotonic()-start;dump('results.json',result)
    print(json.dumps({'checks':len(result['checks']),'failures':len(result['failures']),'error':result.get('error'),'seconds':result['seconds']}))
