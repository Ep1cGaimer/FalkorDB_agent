all Python paths deleted
