def parse():
    return 'base-a'

def helper():
    return 'base-b'
