def parse():
    return 'fixed-a'

def helper():
    return 'fixed-b'
