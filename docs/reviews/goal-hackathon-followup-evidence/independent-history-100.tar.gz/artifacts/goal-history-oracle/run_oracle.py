"""Independent deterministic state oracle; never imports a tested repository.

Run: PYTHONPATH=src /tmp/rw-mcp-compat/bin/python artifacts/goal-history-oracle/run_oracle.py --port PORT
The expected state is maintained by this generator before production indexing.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import random
import subprocess
import time
import traceback

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
COMMANDS = OUT / "git-commands.jsonl"
def digest(data): return hashlib.sha256(data).hexdigest()
def write_json(path, obj): path.write_text(json.dumps(obj, indent=2, sort_keys=True, default=str) + "\n")
def sources():
    return {str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in sorted((ROOT / "src").rglob("*")) if p.is_file() and "__pycache__" not in p.parts}
def git(repo, *args, check=True):
    cmd = ["git", "-c", "user.name=Independent history oracle", "-c", "user.email=history@example.invalid", "-c", "commit.gpgsign=false", "-c", "tag.gpgsign=false", "-C", str(repo), *args]
    result = subprocess.run(cmd, capture_output=True, env={**os.environ,"GIT_AUTHOR_DATE":"2026-01-01T00:00:00+0000","GIT_COMMITTER_DATE":"2026-01-01T00:00:00+0000"})
    with COMMANDS.open("a") as log:
        log.write(json.dumps({"argv":cmd,"returncode":result.returncode,"stdout_sha256":digest(result.stdout),"stderr":result.stderr.decode(errors="replace")})+"\n")
    if check and result.returncode: raise RuntimeError(str(cmd)+": "+result.stderr.decode(errors="replace"))
    return result.stdout.decode().strip() if check else result.returncode

def generate(seed):
    rng = random.Random(seed)
    repo = OUT / "repositories" / f"seed-{seed:03d}"
    repo.mkdir(parents=True)
    git(repo,"init","-q","-b","main")
    symbol = f"f{rng.randrange(100000)}"
    val = rng.randrange(1000000)
    a = f"def {symbol}():\n    return {val}\n"
    b = f"def {symbol}():\n    return 'fix-{seed}-{rng.getrandbits(64):016x}'\n"
    overwritten = f"def {symbol}():\n    raise LookupError\n"
    recreated = f"def {symbol}():\n    return 'new-identity-{seed}'\n"
    states, labels, parents = {}, {}, {}
    def commit(label, files, parent):
        # Synchronize the entire tracked tree from generator-owned state.
        for p in repo.rglob("*"):
            if p.is_file() and ".git" not in p.relative_to(repo).parts and str(p.relative_to(repo)) not in files: p.unlink()
        for name,text in files.items():
            p=repo/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
        git(repo,"add","-A");git(repo,"commit","-qm",f"seed {seed}: {label}")
        sha=git(repo,"rev-parse","HEAD")
        labels[label]=sha;states[sha]=dict(files);parents[sha]=[] if parent is None else [parent]
        return sha
    base=commit("base",{"a.py":a},None)
    fix=commit("fix",{"a.py":b},base)
    revert=commit("revert",{"a.py":a},fix)
    restore=commit("revert_of_revert",{"a.py":b},revert)
    overwrite=commit("overwrite",{"a.py":overwritten},restore)
    delete=commit("delete",{"README.md":f"seed {seed}: deleted\n"},overwrite)
    recreate=commit("delete_recreate",{"README.md":f"seed {seed}: deleted\n","a.py":recreated},delete)
    git(repo,"checkout","-qb","unrelated",base)
    branch=commit("unrelated",{"a.py":f"def {symbol}():\n    return 'unrelated-{seed}'\n"},base)
    git(repo,"checkout","-q","main")
    git(repo,"tag","v-state",fix)
    expected={"seed":seed,"symbol":symbol,"states":states,"labels":labels,"parents":parents,"fix":fix,
              "expected_fix_presence":{sha:sha in (fix,restore) for sha in states},
              "git_plumbing":{},"generation_seconds":None}
    # Verify exact trees and direct parent lists independently of graph output.
    for sha,files in states.items():
        tracked=git(repo,"ls-tree","-r","--name-only",sha).splitlines()
        actual_parents=git(repo,"cat-file","-p",sha).split("\n\n",1)[0].splitlines()
        actual_parents=[x[7:] for x in actual_parents if x.startswith("parent ")]
        assert tracked == sorted(files),(seed,sha,"tree paths")
        assert actual_parents == parents[sha],(seed,sha,"parents")
        for name,text in files.items(): assert git(repo,"show",f"{sha}:{name}")+"\n" == text
        expected["git_plumbing"][sha]={"tree":git(repo,"rev-parse",f"{sha}^{{tree}}"),"paths":tracked,"parents":actual_parents}
    return repo,expected

def run_seed(seed,port):
    from rw import graph as G
    from rw.repo.config import RepoConfig
    from rw.repo.index import index_repository
    from rw.repo.query import RepoQuery
    start=time.monotonic();path=OUT/f"seed-{seed:03d}.json"
    result={"seed":seed,"checks":[],"failures":[],"queries":[],"traces":[]}
    def check(name,actual,expected):
        passed=actual==expected
        entry={"name":name,"pass":passed,"actual":actual,"expected":expected}
        result["checks"].append(entry)
        if not passed:result["failures"].append(entry)
    db=G.connect(port=port)
    graph=f"history_oracle_{seed:03d}"
    reverse=graph+"_reverse"
    try:
        repo,oracle=generate(seed);result["oracle"]=oracle
        write_json(path,result) # Seal expected states on disk before production access.
        labels=oracle["labels"];tip=labels["delete_recreate"];branch=labels["unrelated"]
        cfg=RepoConfig(name=f"independent-{seed:03d}",path=str(repo),revisions=[tip],tag_pattern="^v-state$")
        imports=[]
        imports.append(dataclasses.asdict(index_repository(cfg,graph,db=db)))
        def snapshot(g):
            q=RepoQuery(g,cfg.name,db=db,trace=result["traces"])
            snapshots={}
            for sha,files in oracle["states"].items():
                if sha==branch and g==graph and len(imports)==1:continue
                rows=q._q("MATCH (:Commit {sha:$s})-[f:HAS_FILE]->(b:Blob) RETURN f.path,b.content_hash ORDER BY f.path",{"s":sha})
                expected=[[p,digest(t.encode())] for p,t in sorted(files.items())]
                check(g+":"+sha+":file_state",rows,expected)
                history=q.symbol_history("a."+oracle["symbol"],[sha])[0]
                check(g+":"+sha+":symbol_presence",history.present,"a.py" in files)
                status=q.fix_status(sha,oracle["fix"])
                result["queries"].append({"graph":g,"revision":sha,"symbol_history":dataclasses.asdict(history),"fix_status":dataclasses.asdict(status)})
                check(g+":"+sha+":fix_presence",status.state,"PRESENT" if oracle["expected_fix_presence"][sha] else "ABSENT")
                snapshots[sha]={"files":rows,"symbol_present":history.present,"fix_status":status.state}
            return snapshots
        before=snapshot(graph)
        cfg=cfg.model_copy(update={"revisions":[tip,branch]})
        imports.append(dataclasses.asdict(index_repository(cfg,graph,db=db)))
        after=snapshot(graph)
        check("unrelated_branch_pinned_invariant",{k:after[k] for k in before},before)
        imports.append(dataclasses.asdict(index_repository(cfg.model_copy(update={"revisions":[branch,tip]}),reverse,db=db)))
        reverse_state=snapshot(reverse)
        check("indexing_order_invariant",reverse_state,after)
        q=RepoQuery(graph,cfg.name,db=db,trace=result["traces"])
        for child,expected_parents in oracle["parents"].items():
            rows=q._q("MATCH (:Commit {sha:$s})-[e:PARENT]->(p:Commit) RETURN p.sha ORDER BY e.order",{"s":child})
            check(child+":graph_parents",[x[0] for x in rows],expected_parents)
        check("branch_not_descendant_of_fix",q.is_ancestor(labels["fix"],branch),False)
        check("deleted_descends_from_fix",q.is_ancestor(labels["fix"],labels["delete"]),True)
        check("tag_initial",q.resolve("v-state")[0],labels["fix"])
        git(repo,"tag","-f","v-state",labels["delete"])
        imports.append(dataclasses.asdict(index_repository(cfg,graph,db=db)))
        check("moved_tag",RepoQuery(graph,cfg.name,db=db).resolve("v-state")[0],labels["delete"])
        # Independent repository with identical path and symbol, indexed in the same graph.
        other_repo=OUT/"repositories"/f"other-{seed:03d}";other_repo.mkdir()
        git(other_repo,"init","-q","-b","main")
        (other_repo/"a.py").write_text(f"def {oracle['symbol']}():\n    return 'other-repository'\n")
        git(other_repo,"add","-A");git(other_repo,"commit","-qm","independent repository")
        other_cfg=RepoConfig(name=f"other-{seed:03d}",path=str(other_repo),revisions=["HEAD"])
        imports.append(dataclasses.asdict(index_repository(other_cfg,graph,db=db)))
        check("unrelated_repository_pinned_invariant",snapshot(graph),after)
        result["imports"]=imports
    except Exception:
        result["error"]=traceback.format_exc()
    finally:
        for g in (graph,reverse):
            try:db.select_graph(g).delete()
            except Exception as exc:result.setdefault("cleanup_errors",[]).append(str(exc))
        result["seconds"]=time.monotonic()-start
        write_json(path,result)
    return {"seed":seed,"checks":len(result["checks"]),"failures":len(result["failures"]),"error":result.get("error"),"seconds":result["seconds"]}

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--port",type=int,required=True);parser.add_argument("--count",type=int,default=100);parser.add_argument("--workers",type=int,default=4);args=parser.parse_args()
    assert args.port not in (6379,6382)
    OUT.mkdir(exist_ok=True,parents=True)
    start=time.monotonic();before=sources();write_json(OUT/"source-before.json",before)
    rows=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as executor:
        for row in executor.map(lambda seed:run_seed(seed,args.port),range(args.count)):
            rows.append(row);write_json(OUT/"progress.json",rows)
            print(json.dumps(row),flush=True)
    after=sources();write_json(OUT/"source-after.json",after)
    summary={"seeds":list(range(args.count)),"rows":rows,"source_unchanged":before==after,"source_files":len(before),"seconds":time.monotonic()-start,"port":args.port,"workers":args.workers,"checks":sum(r["checks"] for r in rows),"failures":sum(r["failures"] for r in rows),"errors":sum(bool(r["error"]) for r in rows)}
    write_json(OUT/"summary.json",summary);print(json.dumps(summary),flush=True)

if __name__=="__main__":main()
