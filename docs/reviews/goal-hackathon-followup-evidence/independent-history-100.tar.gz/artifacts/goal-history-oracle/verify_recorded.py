"""Recompute result totals and verify recorded citations against generator states."""
import hashlib
import json
from pathlib import Path

out=Path(__file__).resolve().parent
rows=[json.loads((out/f"seed-{seed:03d}.json").read_text()) for seed in range(100)]
failures=[]
citations=0
fix_states={}
trace_count=0
checks=0
for row in rows:
    checks+=len(row["checks"])
    trace_count+=len(row["traces"])
    assert not row.get("error")
    assert not row["failures"]
    for query in row["queries"]:
        sha=query["revision"]
        states=row["oracle"]["states"][sha]
        status=query["fix_status"]
        fix_states[status["state"]]=fix_states.get(status["state"],0)+1
        all_citations=list(status["citations"])
        if query["symbol_history"]["citation"]:all_citations.append(query["symbol_history"]["citation"])
        for citation in all_citations:
            citations+=1
            content=states.get(citation["path"])
            valid=(citation["commit"]==sha and citation["repo"]==f"independent-{row['seed']:03d}" and content is not None and citation["content_hash"]==hashlib.sha256(content.encode()).hexdigest() and 1<=citation["start_line"]<=citation["end_line"]<=len(content.splitlines()))
            if not valid:failures.append({"seed":row["seed"],"query":query,"citation":citation})
            if status["state"]=="PRESENT" and citation in status["citations"]:
                actual="\n".join(content.splitlines()[citation["start_line"]-1:citation["end_line"]])
                fixed=row["oracle"]["states"][row["oracle"]["fix"]]["a.py"].splitlines()[1]
                if fixed not in actual:failures.append({"seed":row["seed"],"missing_fix_line":fixed,"citation":citation})
expected={"lineage":"Expected states generated in generate(seed), persisted before first index_repository invocation, then retained with observed results. This consolidated view is extracted afterward without changing expected values.","seeds":{str(row["seed"]):row["oracle"] for row in rows}}
(out/"expected-state-manifest.json").write_text(json.dumps(expected,indent=2,sort_keys=True)+"\n")
record={"seeds":len(rows),"checks_recomputed":checks,"queries":sum(len(r["queries"]) for r in rows),"graph_trace_records":trace_count,"fix_state_counts":fix_states,"citations_checked":citations,"citation_failures":failures,"pass":not failures}
(out/"recorded-verification.json").write_text(json.dumps(record,indent=2,sort_keys=True)+"\n")
print(json.dumps(record))
