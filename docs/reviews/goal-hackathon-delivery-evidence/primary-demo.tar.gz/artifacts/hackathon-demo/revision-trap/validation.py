def validate(amount):
    return amount
