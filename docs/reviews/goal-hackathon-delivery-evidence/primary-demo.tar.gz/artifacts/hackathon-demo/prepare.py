import dataclasses,json,os,time
from pathlib import Path
from confirmatory.plaintext_tools import PlaintextTools
from confirmatory.graph_tools import config_for_export
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
from rw.repo.investigate import investigate
os.environ['RW_FALKORDB_PORT']='55688'
raw=PlaintextTools(Path('artifacts/corpus-development/itsdangerous-full-001'))
cfg=config_for_export(raw,Path('artifacts/repos/itsdangerous').resolve()).model_copy(update={'name':'hackathon-itsdangerous'})
# This demo uses inspected development source, never the sealed evaluation corpus.
output=Path('artifacts/hackathon-demo');(output/'config.json').write_text(cfg.model_dump_json(indent=2))
started=time.monotonic();report=index_repository(cfg,'rw_hackathon_demo_itsdangerous')
(output/'import.json').write_text(json.dumps(dataclasses.asdict(report),indent=2))
q=RepoQuery('rw_hackathon_demo_itsdangerous',cfg.name);sha=raw.spec['roots'][0]
page=q.dependencies(sha,'itsdangerous.url_safe.URLSafeTimedSerializer',hops=2,limit=30)
if not page.items:
 candidates=q.symbols(sha,name='URLSafeTimedSerializer')
 print('candidates',[x.qualname for x in candidates.items])
 if candidates.items:page=q.dependencies(sha,candidates.items[0].qualname,hops=2,limit=30)
(output/'two-hop.json').write_text(json.dumps(dataclasses.asdict(page),indent=2))
trace=[]
answer=investigate(cfg.name,sha,'Where is URLSafeTimedSerializer defined?',config=cfg,graph_name='rw_hackathon_demo_itsdangerous',trace=trace)
(output/'definition.json').write_text(json.dumps(answer.to_dict(),indent=2))
(output/'definition-trace.json').write_text(json.dumps(trace,indent=2))
print(json.dumps({'import_status':report.status,'seconds':time.monotonic()-started,'dependency_hops':sorted({x.hops for x in page.items}),'findings':len(answer.findings),'citations':len(answer.citations),'gaps':[x.kind for x in answer.gaps],'source_commit':sha}))
