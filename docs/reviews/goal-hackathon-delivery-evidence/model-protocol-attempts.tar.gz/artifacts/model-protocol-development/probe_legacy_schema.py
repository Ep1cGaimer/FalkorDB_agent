import copy,hashlib,json,os,re,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.grounding import _tls_context
from confirmatory.corpus_export import canonical
from confirmatory.gemini_meter import GeminiAPI,ModelFailure
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
key=os.environ['GEMINI_API_KEY']
old=json.loads(Path('artifacts/model-protocol-development/response-format-probe-001.json').read_text())
out=Path('artifacts/model-protocol-development/legacy-schema-probe-001.json')
with out.open('xb') as f:f.write(canonical({'status':'STARTED'}))
record={'classification':'DEVELOPMENT_PROTOCOL_DIAGNOSTIC_ONLY','acceptance_validated':False,'not_an_investigation':True,'retries':0,'events':[]}
started=time.monotonic()
try:
 with httpx.Client(verify=_tls_context(),follow_redirects=False) as client:
  # This extra count-only request records a sanitized error reason; no generation.
  response=client.post('https://generativelanguage.googleapis.com/v1beta/'+old['model']+':countTokens',headers={'x-goog-api-key':key},json={'generateContentRequest':{'model':old['model'],**old['request']}},timeout=30)
  event={'operation':'new_format_count_error_diagnostic','http_status':response.status_code}
  if response.status_code!=200:
   error=response.json().get('error',{});message=str(error.get('message',''))
   for name in ['GEMINI_API_KEY','GROQ_API_KEY','OPENAI_API_KEY']:
    if os.environ.get(name):message=message.replace(os.environ[name],'<REDACTED>')
   event.update(error_status=error.get('status'),message=message[:2000])
  record['events'].append(event)
  request=copy.deepcopy(old['request'])
  schema=request['generationConfig'].pop('responseFormat')['text']['schema']
  request['generationConfig'].update(responseMimeType='application/json',responseJsonSchema=schema)
  record.update(model=old['model'],request=request,request_sha256=hashlib.sha256(canonical(request)).hexdigest())
  api=GeminiAPI(record['model'],key,client=client)
  record['count']=api.count(request,30-(time.monotonic()-started))
  record['response']=api.generate(request,30-(time.monotonic()-started))
  record['status']='RESPONSE_RECORDED'
except ModelFailure as exc:record.update(status='ERROR',failure=exc.code,http_status=exc.status)
except Exception as exc:record.update(status='ERROR',failure=type(exc).__name__)
record['elapsed_seconds']=time.monotonic()-started
out.write_bytes(canonical(record))
print(json.dumps({k:record.get(k) for k in ['status','failure','http_status','elapsed_seconds','events']}))
