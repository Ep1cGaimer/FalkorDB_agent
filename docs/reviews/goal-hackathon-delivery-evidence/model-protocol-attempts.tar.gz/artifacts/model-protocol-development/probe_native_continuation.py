import copy,hashlib,json,os,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.grounding import _tls_context
from confirmatory.corpus_export import canonical
from confirmatory.gemini_meter import GeminiAPI,ModelFailure
rows=list(map(json.loads,Path('artifacts/model-protocol-development/native-pilot-001/plaintext/events.jsonl').read_text().splitlines()))
request=copy.deepcopy(next(e['request'] for e in rows if e['kind']=='token_count_started'))
content=next(e['response']['candidates'][0]['content'] for e in rows if e['kind']=='generation_completed')
operation=next(e['trace'] for e in rows if e['kind']=='tool_operation')
call=next(p['functionCall'] for p in content['parts'] if 'functionCall' in p)
request['contents'].append(content)
response={'name':call['name'],'response':{'selected_tool':operation['tool'],'tool_result':operation['response']}}
if call.get('id'):response['id']=call['id']
request['contents'].append({'role':'user','parts':[{'functionResponse':response}]})
out=Path('artifacts/model-protocol-development/native-continuation-probe-001.json')
with out.open('xb') as f:f.write(canonical({'status':'STARTED'}))
record={'classification':'RECORDED_FIRST_TURN_PLUS_LIVE_CONTINUATION_PROBE_NOT_AN_INVESTIGATION','acceptance_validated':False,'model':'models/gemini-3.8-flash','deadline_seconds':30,'retries':0,'request':request,'request_sha256':hashlib.sha256(canonical(request)).hexdigest()}
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'));started=time.monotonic()
try:
 with httpx.Client(verify=_tls_context(),follow_redirects=False) as client:
  api=GeminiAPI(record['model'],os.environ['GEMINI_API_KEY'],client=client)
  record['count']=api.count(request,30-(time.monotonic()-started))
  record['response']=api.generate(request,30-(time.monotonic()-started))
  record['status']='RESPONSE_RECORDED'
except ModelFailure as exc:record.update(status='ERROR',failure=exc.code,http_status=exc.status)
except Exception as exc:record.update(status='ERROR',failure=type(exc).__name__)
record['elapsed_seconds']=time.monotonic()-started;out.write_bytes(canonical(record))
print(json.dumps({k:record.get(k) for k in ['status','failure','http_status','elapsed_seconds']}))
