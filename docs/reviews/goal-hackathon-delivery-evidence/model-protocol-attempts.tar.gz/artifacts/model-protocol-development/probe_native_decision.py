import copy,hashlib,json,os,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.grounding import _tls_context
from confirmatory.corpus_export import canonical
from confirmatory.gemini_meter import GeminiAPI,ModelFailure
old=json.loads(Path('artifacts/model-development/native-none-probe-001.json').read_text())
request=copy.deepcopy(old['request'])
request['generationConfig'].pop('responseMimeType',None)
request['systemInstruction']['parts'][0]['text'] += '\nTransport: return the one JSON decision as arguments of the declared select_action function. This replaces JSON text rendering only; no function is executed by the provider.'
schema={'type':'object','properties':{'action':{'type':'string','enum':['call','finish']},'name':{'type':'string'},'arguments':{'type':'object','additionalProperties':True}},'required':['action'],'additionalProperties':False}
request['tools']=[{'functionDeclarations':[{'name':'select_action','description':'Select a single retrieval action or finish; application validates permissions before dispatch.','parametersJsonSchema':schema}]}]
request['toolConfig']={'functionCallingConfig':{'mode':'ANY','allowedFunctionNames':['select_action']}}
out=Path('artifacts/model-protocol-development/native-decision-probe-001.json')
with out.open('xb') as f:f.write(canonical({'status':'STARTED'}))
record={'classification':'DEVELOPMENT_NATIVE_DECISION_PROTOCOL_PROBE_ONLY','acceptance_validated':False,'not_an_investigation':True,'model':old['model'],'deadline_seconds':30,'retries':0,'request':request,'request_sha256':hashlib.sha256(canonical(request)).hexdigest()}
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
started=time.monotonic()
try:
 with httpx.Client(verify=_tls_context(),follow_redirects=False) as client:
  api=GeminiAPI(record['model'],os.environ['GEMINI_API_KEY'],client=client)
  record['count']=api.count(request,30-(time.monotonic()-started))
  record['response']=api.generate(request,30-(time.monotonic()-started))
  record['status']='RESPONSE_RECORDED'
except ModelFailure as exc:record.update(status='ERROR',failure=exc.code,http_status=exc.status)
except Exception as exc:record.update(status='ERROR',failure=type(exc).__name__)
record['elapsed_seconds']=time.monotonic()-started
out.write_bytes(canonical(record))
print(json.dumps({k:record.get(k) for k in ['status','failure','http_status','elapsed_seconds']}))
