import json,os,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.grounding import _tls_context
from confirmatory.corpus_export import canonical
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
out=Path('artifacts/model-protocol-development/model-metadata-001.json')
with out.open('xb') as stream:stream.write(canonical({'status':'STARTED'}))
r={'classification':'DEVELOPMENT_PROVIDER_MODEL_METADATA_ONLY','acceptance_validated':False,'models':[]}
with httpx.Client(verify=_tls_context(),follow_redirects=False,timeout=10) as client:
 for name in ['models/gemini-3.8-flash','models/gemini-3.6-flash','models/gemini-2.5-flash']:
  started=time.monotonic();item={'requested':name}
  try:
   response=client.get('https://generativelanguage.googleapis.com/v1beta/'+name,headers={'x-goog-api-key':os.environ['GEMINI_API_KEY']})
   item['http_status']=response.status_code
   if response.status_code==200:
    data=response.json();item['metadata']={k:data[k] for k in ['name','baseModelId','version','displayName','inputTokenLimit','outputTokenLimit','supportedGenerationMethods','temperature','topP','topK'] if k in data}
  except Exception as exc:item['failure']=type(exc).__name__
  item['seconds']=time.monotonic()-started;r['models'].append(item)
  out.write_bytes(canonical(r))
print(json.dumps(r,sort_keys=True))
