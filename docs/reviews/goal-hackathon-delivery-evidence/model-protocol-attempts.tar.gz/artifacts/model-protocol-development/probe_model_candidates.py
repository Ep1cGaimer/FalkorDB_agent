import copy,hashlib,json,os,time
from pathlib import Path
import httpx
from rw.config import load_env
from rw.grounding import _tls_context
from confirmatory.corpus_export import canonical
from confirmatory.gemini_meter import GeminiAPI,Journal,MeteredModel,ModelLimits,ModelFailure
# Availability probes, not quality/model-selection scores. Predetermined order.
original=next(e['request'] for e in map(json.loads,Path('artifacts/model-development/citation-pilot-001/graph/events.jsonl').read_text().splitlines()) if e['kind']=='token_count_started')
out=Path('artifacts/model-protocol-development/model-candidates-001');out.mkdir(exist_ok=False)
record={'classification':'DEVELOPMENT_FIRST_ACTION_AVAILABILITY_PROBES_ONLY','acceptance_validated':False,'planned_order':['models/gemini-3.6-flash','models/gemini-2.5-flash'],'selection_rule':'Prefer3.6 if protocol completes;otherwise2.5 if protocol completes;no quality claim or automatic runtime fallback','attempts':[]}
(out/'plan.json').write_bytes(canonical(record))
load_env(Path('/Users/vinay2047/Documents/github/FalkorDB_agent/.env'))
for name in record['planned_order']:
 journal=Journal(out/name.split('/')[-1]);result={'model':name,'status':'STARTED'}
 with httpx.Client(verify=_tls_context(),follow_redirects=False) as client:
  model=MeteredModel(GeminiAPI(name,os.environ['GEMINI_API_KEY'],client=client),journal,ModelLimits(seconds=30),generation={'responseMimeType':'application/json'})
  try:
   text=model.ask(original['systemInstruction']['parts'][0]['text'],original['contents'],phase='retrieval')
   value=json.loads(text)
   assert value.get('action')=='call' and isinstance(value.get('name'),str) and isinstance(value.get('arguments'),dict)
   result.update(status='PROTOCOL_RESPONSE_RECORDED',decision=value)
  except ModelFailure as exc:result.update(status='ERROR',failure=exc.code)
  except Exception as exc:result.update(status='ERROR',failure=type(exc).__name__)
  result['model_usage']=model.summary();journal.write_new('result.json',result)
 record['attempts'].append(result);(out/'summary.json').write_bytes(canonical(record))
print(json.dumps(record['attempts'],sort_keys=True))
