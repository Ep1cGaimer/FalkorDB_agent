import json,subprocess
from pathlib import Path
root=Path('/audit/work/clean-control');root.mkdir()
Path('/audit/adversarial-config.json').write_bytes(Path('/audit/config.json').read_bytes())
(root/'safe.py').write_text('def safe():\n    return 1\n')
for args in [('init','-q','-b','main'),('add','.'),('commit','-qm','trusted clean audit control')]:
 subprocess.check_call(['git','-c','user.name=Audit','-c','user.email=audit@example.invalid','-c','commit.gpgsign=false','-C',str(root),*args])
sha=subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD']).decode().strip()
Path('/audit/config.json').write_text(json.dumps({'name':'clean-control','path':str(root),'revisions':[sha],'include':['*.py'],'exclude':[]}))
