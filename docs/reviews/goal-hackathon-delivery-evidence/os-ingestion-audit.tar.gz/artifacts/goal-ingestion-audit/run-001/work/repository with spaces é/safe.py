def safe():
    return 1
