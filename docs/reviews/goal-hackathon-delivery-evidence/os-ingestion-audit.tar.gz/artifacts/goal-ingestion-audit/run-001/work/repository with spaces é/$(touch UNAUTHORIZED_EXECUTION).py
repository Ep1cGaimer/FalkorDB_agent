from pathlib import Path
Path('/audit/work/UNAUTHORIZED_EXECUTION').write_text("EXECUTED")
