"""Trusted, isolated ingestion entry point for the OS audit."""
import dataclasses,json,sys
from pathlib import Path
sys.path.insert(0,'/repo/src')
from rw.repo.config import RepoConfig
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
cfg=RepoConfig.model_validate(json.loads(Path('/audit/config.json').read_text()))
report=index_repository(cfg,'rw_os_ingestion_audit')
q=RepoQuery('rw_os_ingestion_audit',cfg.name)
ambiguous=q.symbols(cfg.revisions[0],name='safe')
print(json.dumps({'broad_name_items':[x.qualname for x in ambiguous.items],'report_status':report.status}))
page=q.symbols(cfg.revisions[0],name='safe.safe')
assert report.status=='COMPLETE' and len(page.items)==1
assert not (Path('/audit/work/UNAUTHORIZED_EXECUTION')).exists()
print(json.dumps({'classification':'SYNTHETIC_OS_AUDITED_INGESTION_NOT_FULL_T8','report':dataclasses.asdict(report),'safe_symbol_citation':dataclasses.asdict(page.items[0].citation),'marker_absent':True},sort_keys=True))
