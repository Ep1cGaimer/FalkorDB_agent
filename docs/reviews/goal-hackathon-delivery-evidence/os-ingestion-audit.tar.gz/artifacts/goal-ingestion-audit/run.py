import ast,hashlib,json,os,re,shutil,subprocess,time,traceback,uuid
from pathlib import Path
root=Path.cwd();base=root/'artifacts/goal-ingestion-audit';out=base/'run-001';out.mkdir(exist_ok=False)
for name in ['setup.py','ingest.py']:shutil.copyfile(base/name,out/name)
venv=Path('/private/tmp/rw-independent-812ecf7-z_wmyild/linux-venv-attempt2')
db='rw-goal-ingestion-audit-'+uuid.uuid4().hex[:10]
image='rw-goal-audit:20261018'
r={'classification':'PARENT_SYNTHETIC_OS_AUDIT_NOT_FULL_T8','acceptance_validated':False,'owned_container':db,'commands':[]}
source={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((root/'src').rglob('*.py'))}
(out/'source-before.json').write_text(json.dumps(source,indent=2)+'\n')
def command(args,name):
 started=time.monotonic()
 with (out/(name+'.log')).open('wb') as stream:p=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT)
 r['commands'].append({'command':list(map(str,args)),'exit_code':p.returncode,'seconds':time.monotonic()-started})
 (out/'progress.json').write_text(json.dumps(r,indent=2)+'\n')
 if p.returncode:raise RuntimeError(name+' failed')
try:
 command(['docker','image','inspect',image],'image')
 command(['docker','run','-d','--name',db,'--memory=1g','falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'],'db-start')
 for _ in range(40):
  p=subprocess.run(['docker','exec',db,'redis-cli','PING'],capture_output=True)
  if p.returncode==0 and p.stdout.strip()==b'PONG':break
  time.sleep(.1)
 else:raise RuntimeError('DB not ready')
 run=['docker','run','--rm','--network','container:'+db,'--read-only','--tmpfs','/tmp:rw,size=64m',
      '-v',str(root/'src')+':/repo/src:ro','-v',str(venv)+':'+str(venv)+':ro','-v',str(out)+':/audit',
      '-w','/audit','-e','PYTHONDONTWRITEBYTECODE=1','-e','RW_FALKORDB_HOST=127.0.0.1','-e','RW_FALKORDB_PORT=6379',image]
 command(run+[str(venv/'bin/python'),'-I','-B','/audit/setup.py'],'setup')
 meta=json.loads((out/'setup.json').read_text())
 trace=['strace','-f','-ttt','-s','8192','-e','trace=process,network,file']
 command(run+trace+['-o','/audit/positive-control.strace',meta['canary']],'positive-control')
 marker=out/'work/UNAUTHORIZED_EXECUTION'
 assert marker.exists(),'positive control did not execute'
 control=(out/'positive-control.strace').read_text()
 controls={'execution':bool(re.search(r'execve\(.*tracked-canary.*= 0',control)),
           'write':bool(re.search(r'openat\(.*UNAUTHORIZED_EXECUTION.*O_WRONLY',control)),
           'network':bool(re.search(r'sendto\(.*htons\(9\)',control))}
 assert all(controls.values()),controls
 r['positive_control']=controls;marker.unlink()
 command(run+trace+['-o','/audit/ingestion.strace',str(venv/'bin/python'),'-I','-B','/audit/ingest.py'],'ingestion')
 data=(out/'ingestion.strace').read_text()
 executions=[]
 for line in data.splitlines():
  if 'execve(' in line and re.search(r'= 0$',line):
   match=re.search(r'execve\(("(?:[^"\\]|\\.)*")',line)
   if match:executions.append(ast.literal_eval(match[1]))
 unexpected=[p for p in executions if p not in {str(venv/'bin/python'),'/usr/bin/git'}]
 writes=[line for line in data.splitlines() if re.search(r'\b(?:open|openat)\(.*\bO_(?:WRONLY|RDWR)\b|\b(?:creat|unlink|rename|mkdir|rmdir|symlink|link)\(',line)]
 connections=[line for line in data.splitlines() if re.search(r'\bconnect\(',line)]
 bad_network=[line for line in connections if not ('sin_port=htons(6379)' in line and 'inet_addr("127.0.0.1")' in line)]
 bad_datagrams=[line for line in data.splitlines() if re.search(r'\bsendto\(.*(?:sin_port|sin6_port)=',line)]
 outside_reads=[line for line in data.splitlines() if re.search(r'\bopen(?:at)?\(.*OUTSIDE_SECRET',line)]
 r.update(executions=executions,unexpected_executions=unexpected,filesystem_write_operations=writes,
          connect_operations=connections,unexpected_network_operations=bad_network+bad_datagrams,
          outside_target_opens=outside_reads,marker_absent=not marker.exists(),trace_lines=len(data.splitlines()))
 assert executions and not unexpected and not writes and not bad_network and not bad_datagrams and not outside_reads and not marker.exists()
 r['status']='PASS'
except Exception as exc:
 r.update(status='ERROR',failure=type(exc).__name__);(out/'driver-error.txt').write_text(traceback.format_exc())
finally:
 p=subprocess.run(['docker','rm','-f',db],capture_output=True)
 r['cleanup']={'remove_exit_code':p.returncode,'remaining':subprocess.check_output(['docker','ps','-a','--filter','name='+db,'--format','{{.Names}}']).decode().splitlines()}
 r['source_mismatches']=[p for p,h in source.items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
 (out/'summary.json').write_text(json.dumps(r,indent=2)+'\n')
 print(json.dumps({k:r.get(k) for k in ['status','failure','positive_control','unexpected_executions','filesystem_write_operations','unexpected_network_operations','outside_target_opens','marker_absent','trace_lines','cleanup','source_mismatches']}))
