"""Unseen config-only import trial. Reads public corpus identities, never tasks/oracles."""
import hashlib, json, subprocess, time, uuid
from pathlib import Path

root = Path.cwd()
out = root / 'artifacts/goal-unseen-onboarding/trial-001'
out.mkdir(parents=True, exist_ok=False)
qa = json.loads((root/'artifacts/goal-current-qa/full-003/summary.json').read_text())
stage = Path(qa['stage'])
pin = json.loads((root/'artifacts/goal-current-qa/full-003/source-before.json').read_text())
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==h for p,h in pin['files'].items())
(out/'source-before.json').write_text(json.dumps(pin, indent=2)+'\n')
public = json.loads((root/'evals/confirmatory/corpus.draft-v1.json').read_text())['repositories']['click']
roots = [s['commit'] for s in public['snapshots']]
cfg = dict(name='unseen-click-001', path='/corpus/repository with spaces é', revisions=roots,
           tag_pattern='(?!)', languages=['python'], path_matching='path', regular_files_only=True,
           include=['click/*.py','src/click/*.py','pyproject.toml','setup.cfg','setup.py','HISTORY*','CHANGES*','CHANGELOG*'],
           exclude=['tests/*','examples/*','docs/*'])
(out/'config.json').write_text(json.dumps(cfg, indent=2)+'\n')
trusted = '''import dataclasses,json,time
from pathlib import Path
from rw.repo.config import load_config
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
cfg=load_config('/audit/config.json')
started=time.monotonic()
report=index_repository(cfg,'rw_unseen_click_001')
q=RepoQuery('rw_unseen_click_001',cfg.name)
resolved=[{'requested':sha,'resolved':q.resolve(sha)[0],'gap':str(q.resolve(sha)[1])} for sha in cfg.revisions]
result={'seconds':time.monotonic()-started,'report':dataclasses.asdict(report),'resolved':resolved,'config_only':True,'generated_answers':False,'heldout_questions_run':0}
Path('/audit/import.json').write_text(json.dumps(result,indent=2)+'\\n')
assert report.status=='COMPLETE'
assert all(x['requested']==x['resolved'] and x['gap']=='None' for x in resolved)
print(json.dumps({'status':report.status,'seconds':result['seconds'],'metrics':report.metrics,'roots_verified':len(resolved)}))
'''
(out/'import.py').write_text(trusted)
db='rw-unseen-click-'+uuid.uuid4().hex[:10]
record={'classification':'FIRST_CONFIG_ONLY_UNSEEN_CLICK_TRIAL_NOT_FULL_T1','started_at':time.time(),
        'core_pin':'artifacts/goal-current-qa/full-003/source-before.json',
        'plan_frozen':False,'acceptance_validated':False,'heldout_questions_run':0,
        'source_inspection':'No parent Click source inspection before this trial; independent evaluator previously authored source-only questions. Trial only imports and resolves declared roots. No tuning against trial outputs.',
        'commands':[],'owned_container':db}
def command(args,label,timeout=300):
    start=time.monotonic()
    with (out/(label+'.log')).open('wb') as stream:
        p=subprocess.run(args,stdout=stream,stderr=subprocess.STDOUT,timeout=timeout)
    record['commands'].append({'command':args,'exit_code':p.returncode,'seconds':time.monotonic()-start})
    (out/'progress.json').write_text(json.dumps(record,indent=2)+'\n')
    if p.returncode: raise RuntimeError(label+' failed')
try:
    clone=out/'repository with spaces é'
    command(['git','clone','--bare','--no-hardlinks',str(root/public['bare_path']),str(clone)],'clone')
    command(['git','-C',str(clone),'remote','set-url','origin',public['origin']],'origin')
    command(['docker','run','-d','--name',db,'--memory=2g',
             'falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'],'database')
    venv='/private/tmp/rw-independent-812ecf7-z_wmyild/linux-venv-attempt2'
    command(['docker','run','--rm','--network','container:'+db,'--read-only','--memory=3g','--tmpfs','/tmp:rw,size=128m',
             '-v',str(stage)+':/repo:ro','-v',str(out)+':/audit','-v',str(clone)+':/corpus/repository with spaces é:ro',
             '-v',venv+':'+venv+':ro','-w','/repo','-e','PYTHONPATH=/repo/src','-e','PYTHONDONTWRITEBYTECODE=1',
             '-e','RW_FALKORDB_HOST=127.0.0.1','-e','RW_FALKORDB_PORT=6379',
             'rw-goal-qa:20261018',venv+'/bin/python','-B','/audit/import.py'],'import',timeout=600)
    record['status']='PASS'
except Exception as exc:
    record['status']='ERROR';record['error_type']=type(exc).__name__
finally:
    p=subprocess.run(['docker','rm','-f',db],capture_output=True)
    record['cleanup']={'exit_code':p.returncode,'remaining':subprocess.check_output(['docker','ps','-a','--filter','name='+db,'--format','{{.Names}}']).decode().splitlines()}
    record['source_mismatches']=[p for p,h in pin['files'].items() if hashlib.sha256((root/p).read_bytes()).hexdigest()!=h]
    record['finished_at']=time.time()
    (out/'summary.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':record['status'],'source_mismatches':record['source_mismatches']}))
