import dataclasses,json,time
from pathlib import Path
from rw.repo.config import load_config
from rw.repo.index import index_repository
from rw.repo.query import RepoQuery
cfg=load_config('/audit/config.json')
started=time.monotonic()
report=index_repository(cfg,'rw_unseen_click_001')
q=RepoQuery('rw_unseen_click_001',cfg.name)
resolved=[{'requested':sha,'resolved':q.resolve(sha)[0],'gap':str(q.resolve(sha)[1])} for sha in cfg.revisions]
result={'seconds':time.monotonic()-started,'report':dataclasses.asdict(report),'resolved':resolved,'config_only':True,'generated_answers':False,'heldout_questions_run':0}
Path('/audit/import.json').write_text(json.dumps(result,indent=2)+'\n')
assert report.status=='COMPLETE'
assert all(x['requested']==x['resolved'] and x['gap']=='None' for x in resolved)
print(json.dumps({'status':report.status,'seconds':result['seconds'],'metrics':report.metrics,'roots_verified':len(resolved)}))
