"""Human-approval-bound local fleet simulation with an atomic SQLite ledger."""
from __future__ import annotations

from contextlib import closing, contextmanager
from datetime import datetime, timezone
from pathlib import Path
import sqlite3

from rw.contracts import (REPO_ROOT, Approval, CandidatePlan, Disposition, FleetEntry,
                          SimulationReceipt, VerificationResult, canonical_json, fleet_hash, h)

DEFAULT_DB_PATH = REPO_ROOT / "artifacts" / "sim.sqlite"


def _configured_model_identities() -> set[str]:
    """The model's own label plus every configured chain entry and its bare model name.

    ``rw.grounding`` is imported inside this function rather than at module scope, so this module
    never joins a grounding import cycle.
    """
    from rw import grounding
    identities = {grounding.MODEL}
    for spec in grounding.configured_models():
        identities.add(spec)
        identities.add(grounding.split_model(spec)[1])
    return identities


# A model can never approve its own proposal: the base non-human names plus every configured model.
DEFAULT_FORBIDDEN_IDENTITIES = frozenset({"agent", "model"} | _configured_model_identities())


class SimulationRefused(Exception):
    def __init__(self, reason: str):
        self.reason = reason
        super().__init__(reason)


@contextmanager
def _transaction(db_path):
    try:
        path = Path(db_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(path, timeout=30)) as connection, connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute("CREATE TABLE IF NOT EXISTS approvals (approval_hash TEXT PRIMARY KEY, approval_json TEXT NOT NULL)")
            connection.execute("CREATE TABLE IF NOT EXISTS simulation_receipts (idempotency_key TEXT PRIMARY KEY, receipt_json TEXT NOT NULL)")
            connection.execute("CREATE TABLE IF NOT EXISTS simulated_fleet (idempotency_key TEXT PRIMARY KEY, fleet_json TEXT NOT NULL)")
            yield connection
    except (sqlite3.Error, OSError) as exc:
        raise SimulationRefused(f"ledger error: {exc}") from exc


def _validate(approval, verification):
    if approval is None or verification is None:
        raise SimulationRefused("approval and verification required")
    if verification.disposition != Disposition.BOUNDED_PASS:
        raise SimulationRefused("verification is not BOUNDED_PASS")
    if approval.verification_hash != verification.verification_hash():
        raise SimulationRefused("verification hash mismatch")
    if approval.plan_hash != verification.plan_hash:
        raise SimulationRefused("plan hash mismatch")
    if approval.snapshot_manifest_hash != verification.snapshot_manifest_hash:
        raise SimulationRefused("snapshot manifest hash mismatch")


def record_approval(db_path=DEFAULT_DB_PATH, approval: Approval | None = None,
                    verification: VerificationResult | None = None,
                    forbidden_identities=DEFAULT_FORBIDDEN_IDENTITIES) -> None:
    _validate(approval, verification)
    forbidden = {value.strip().casefold() for value in forbidden_identities}
    identity = approval.approved_by.strip().casefold()
    if not identity or identity in forbidden:
        raise SimulationRefused("approval requires a human identity")
    with _transaction(db_path) as connection:
        connection.execute("INSERT OR IGNORE INTO approvals VALUES (?, ?)",
                           (h(approval), approval.model_dump_json()))


def _fleet_dump(fleet: list[FleetEntry]):
    return sorted([entry.model_dump(mode="json") for entry in fleet], key=canonical_json)


def simulate(db_path=DEFAULT_DB_PATH, approval: Approval | None = None,
             verification: VerificationResult | None = None,
             current_manifest_hash: str | None = None,
             current_fleet: list[FleetEntry] | None = None,
             plan: CandidatePlan | None = None) -> SimulationReceipt:
    with _transaction(db_path) as connection:
        _validate(approval, verification)
        if not connection.execute("SELECT 1 FROM approvals WHERE approval_hash = ?", (h(approval),)).fetchone():
            raise SimulationRefused("approval not recorded")
        if current_manifest_hash != approval.snapshot_manifest_hash:
            raise SimulationRefused("stale snapshot manifest")
        if plan is None or plan.plan_hash() != approval.plan_hash:
            raise SimulationRefused("plan hash mismatch")
        if (plan.snapshot_manifest_hash != approval.snapshot_manifest_hash
                or plan.snapshot_id != verification.snapshot_id):
            raise SimulationRefused("plan snapshot mismatch")
        if current_fleet is None:
            raise SimulationRefused("current fleet required")
        key = approval.idempotency_key()
        existing = connection.execute("SELECT receipt_json FROM simulation_receipts WHERE idempotency_key = ?", (key,)).fetchone()
        if existing:
            return SimulationReceipt.model_validate_json(existing[0]).model_copy(update={"applied": False})
        # after the idempotency lookup, before the first application: the applied plan must still be
        # the plan for the fleet it was built against (a repeat above stays a no-op instead)
        observed = fleet_hash(current_fleet)
        if plan.baseline_fleet_hash != observed:
            raise SimulationRefused("current fleet changed since the plan was built")
        fleet_dump = _fleet_dump(plan.fleet)
        receipt = SimulationReceipt(
            idempotency_key=key, plan_hash=approval.plan_hash, applied=True,
            previous_fleet_hash=observed, new_fleet_hash=h(fleet_dump),
            applied_at=datetime.now(timezone.utc).isoformat())
        connection.execute("INSERT INTO simulated_fleet VALUES (?, ?)", (key, canonical_json(fleet_dump).decode("utf-8")))
        connection.execute("INSERT INTO simulation_receipts VALUES (?, ?)", (key, receipt.model_dump_json()))
        return receipt
