"""Supplementary recorded-oracle, prior-snapshot and mid-query generation checks."""
import concurrent.futures,dataclasses,hashlib,json,threading,time
from pathlib import Path
from unittest.mock import patch
from rw import graph as G
import rw.repo.index as I
from rw.repo.config import RepoConfig
from rw.repo.query import RepoQuery
out=Path(__file__).resolve().parent;attempt=out/'attempt003'
cfg=RepoConfig.model_validate_json((attempt/'target-config.json').read_text());oracle=json.loads((attempt/'expected-state.json').read_text());base=oracle['labels']['base'];tip=oracle['labels']['merge']
oldcfg=cfg.model_copy(update={'revisions':[base],'tag_pattern':None});db=G.connect(port=59327)
graph='recovery_supplement';checks=[];record={};trace=[]
def check(name,actual,expected):checks.append({'name':name,'actual':actual,'expected':expected,'pass':actual==expected})
try:
 old=I.index_repository(oldcfg,graph,db=db);gtype=type(db.select_graph(graph));original=gtype.query
 def fail_before_started(self,cypher,*args,**kw):
  if self.name==graph and "r.status='STARTED'" in cypher:raise RuntimeError('supplement before STARTED mutation')
  return original(self,cypher,*args,**kw)
 try:
  with patch.object(gtype,'query',fail_before_started):I.index_repository(cfg,graph,db=db)
 except Exception as exc:record['prior_snapshot_update_error']=repr(exc)
 prior=RepoQuery(graph,cfg.name,db=db,trace=trace).symbols(base)
 check('prior-snapshot-explicit-revision',prior.coverage.get('commit'),base)
 check('prior-snapshot-explicit-generation',prior.coverage.get('generation'),old.import_run_id)
 record['prior_snapshot']=dataclasses.asdict(prior)
 q=RepoQuery(graph,cfg.name,db=db,trace=trace);original_q=q._q;entered=threading.Event();release=threading.Event()
 def pause_after_read(cypher,params=None):
  rows=original_q(cypher,params)
  if 'HAS_FILE' in cypher and not entered.is_set():entered.set();release.wait(5)
  return rows
 q._q=pause_after_read
 with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
  future=pool.submit(q.symbols,base)
  check('mid-query-reached-read-boundary',entered.wait(5),True)
  updated=I.index_repository(cfg,graph,db=db);release.set()
  try:answer=future.result(timeout=10);error=None
  except Exception as exc:answer=None;error=repr(exc)
 check('mid-query-explicit-generation-rejection',error is not None and 'IndexChangedError' in error,True)
 record['mid_query']={'error':error,'answer':dataclasses.asdict(answer) if answer else None,'old_generation':old.import_run_id,'new_generation':updated.import_run_id}
 fresh=RepoQuery(graph,cfg.name,db=db,trace=trace)
 history=fresh.symbol_history('added.added',[base,oracle['labels']['add'],oracle['labels']['delete'],tip])
 check('deleted-current-symbol-independent-oracle',[h.present for h in history],[False,True,False,False])
 check('deleted-historical-citation-identity',history[1].citation.commit,oracle['labels']['add'])
 oldstable=fresh.symbols(base,'stable.stable');newstable=fresh.symbols(tip,'stable.stable')
 check('reused-blob-hash-stable',oldstable.items[0].citation.content_hash,newstable.items[0].citation.content_hash)
 check('reused-old-revision-citation',oldstable.items[0].citation.commit,base)
 check('reused-new-revision-citation',newstable.items[0].citation.commit,tip)
 record['historical_and_reused']={'history':[dataclasses.asdict(x) for x in history],'old_stable':dataclasses.asdict(oldstable),'new_stable':dataclasses.asdict(newstable)}
finally:
 db.select_graph(graph).delete();record['checks']=checks;record['traces']=trace
 (out/'supplement-results.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({'checks':len(checks),'failures':sum(not c['pass'] for c in checks)}))
