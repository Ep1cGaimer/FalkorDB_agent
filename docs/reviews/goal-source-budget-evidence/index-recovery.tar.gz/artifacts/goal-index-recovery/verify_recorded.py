"""Recompute recorded equality assertions and recovery timing without a database."""
import hashlib,json,math,statistics
from pathlib import Path
out=Path(__file__).resolve().parent
attempt=out/'attempt003'
result=json.loads((attempt/'results.json').read_text())
supp=json.loads((out/'supplement-results.json').read_text())
faults=json.loads((attempt/'fault-results.json').read_text())
failures=[]
for source,rows in [('attempt003',result['checks']),('supplement',supp['checks'])]:
 for row in rows:
  actual=row['actual']==row['expected']
  if not actual or actual!=row['pass']:failures.append({'source':source,'check':row})
times=sorted(x['recovery_seconds'] for x in faults)
summary=json.loads((out/'summary.json').read_text())
summary['recovery_seconds']={'min':times[0],'median':statistics.median(times),'p95_nearest_rank':times[math.ceil(.95*len(times))-1],'max':times[-1]}
(out/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
record={'state_checks_recomputed':len(result['checks']),'supplement_checks_recomputed':len(supp['checks']),'failures':failures,'recovery_seconds':summary['recovery_seconds'],'faults':len(faults),'all_faults_share_recovered_normalized_hash':len({x['normalized_sha256'] for x in faults})==1}
(out/'recorded-verification.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record))
