"""Independent T4 synthetic recovery matrix. No application source changes."""
import argparse,collections,concurrent.futures,dataclasses,datetime,hashlib,json,os,random,subprocess,sys,threading,time,traceback
from pathlib import Path
from unittest.mock import patch
from rw import graph as G
import rw.repo.index as I
from rw.repo.adapters import ADAPTERS
from rw.repo.config import RepoConfig
from rw.repo.query import RepoQuery
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[1]
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True,default=str)+'\n')
def digest(b):return hashlib.sha256(b).hexdigest()
def pin():
    expected=json.loads((ROOT/'docs/reviews/goal-hackathon-delivery-evidence/implementation-manifest.json').read_text())['files']
    actual={p:digest((ROOT/p).read_bytes()) for p in expected}
    return {'expected':expected,'actual':actual,'all_match':expected==actual,'count':len(actual),'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def git(repo,*args):
    cmd=['git','-c','user.name=Independent recovery oracle','-c','user.email=recovery@example.invalid','-c','commit.gpgsign=false','-c','tag.gpgsign=false','-C',str(repo),*args]
    r=subprocess.run(cmd,capture_output=True,text=True,check=True,env={**os.environ,'GIT_AUTHOR_DATE':'2026-01-03T00:00:00+0000','GIT_COMMITTER_DATE':'2026-01-03T00:00:00+0000'})
    with (OUT/'git-commands.jsonl').open('a') as f:f.write(json.dumps({'argv':cmd,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr})+'\n')
    return r.stdout.strip()
DROP={'generation','published_run','started_at','finished_at','metrics_json','import_run_id','index_generation'}
def norm(value):
    if dataclasses.is_dataclass(value):value=dataclasses.asdict(value)
    if isinstance(value,dict):return {k:norm(v) for k,v in sorted(value.items()) if k not in DROP}
    if isinstance(value,(list,tuple)):return [norm(v) for v in value]
    return value
def canonical(value):return json.dumps(norm(value),sort_keys=True,separators=(',',':'))
class InjectedFailure(RuntimeError):pass

def child(args):
    cfg=RepoConfig.model_validate_json((OUT/'target-config.json').read_text());db=G.connect(port=args.port)
    if args.child=='crash':
        I.IMPORT_LEASE_SECONDS=2;ADAPTERS['python'].version='independent-t4-extractor-epoch2';original=I._write
        def crash(graph,cypher,rows):
            original(graph,cypher,rows)
            if 'DETACH DELETE s' in cypher and rows:
                (OUT/'process-crash-marker').write_text(cypher);os._exit(73)
        I._write=crash
    report=I.index_repository(cfg,args.graph,db=db)
    print(json.dumps(dataclasses.asdict(report)),flush=True)

def main(args):
    OUT.mkdir(parents=True,exist_ok=True);dump('source-before.json',pin());start=time.monotonic()
    db=G.connect(port=args.port);graphs=[];events=[];checks=[];failures=[]
    def check(name,actual,expected):
        row={'name':name,'actual':actual,'expected':expected,'pass':actual==expected};checks.append(row)
        if not row['pass']:failures.append(row)
    def graph(name):
        name='recovery_'+name;graphs.append(name);return name
    def state(name):
        g=db.select_graph(name)
        return {'repository':g.ro_query('MATCH (r:Repository) RETURN properties(r)').result_set,
                'runs':g.ro_query('MATCH (r:ImportRun) RETURN r.id,r.status ORDER BY r.id').result_set}
    repo=OUT/'repository';repo.mkdir();git(repo,'init','-q','-b','main');states={};labels={};parents={}
    def commit(label,files,parent):
        for p in repo.rglob('*'):
            if p.is_file() and '.git' not in p.relative_to(repo).parts and str(p.relative_to(repo)) not in files:p.unlink()
        for path,text in files.items():(repo/path).write_text(text)
        git(repo,'add','-A');git(repo,'commit','-qm',label);s=git(repo,'rev-parse','HEAD');states[s]=dict(files);labels[label]=s;parents[s]=parent;return s
    stable='def stable():\n    return 42\n';a='def helper():\n    return 1\n\ndef run():\n    return helper()\n'
    basefiles={'a.py':a,'stable.py':stable,'CHANGELOG.md':'# v1\nInitial\n'}
    base=commit('base',basefiles,[])
    added=commit('add',{**basefiles,'added.py':'from a import run\ndef added():\n    return run()\n'},[base])
    editedfiles={**states[added],'a.py':a.replace('return 1','return 2')}
    edited=commit('edit',editedfiles,[added])
    renamedfiles={k:v for k,v in editedfiles.items() if k!='a.py'};renamedfiles['engine.py']=editedfiles['a.py']+'\n# renamed with edits\n'
    renamed=commit('rename',renamedfiles,[edited])
    deletedfiles={k:v for k,v in renamedfiles.items() if k!='added.py'}
    deleted=commit('delete',deletedfiles,[renamed])
    git(repo,'checkout','-qb','feature')
    feature=commit('feature',{**deletedfiles,'feature.py':'from engine import run\ndef feature():\n    return run()\n'},[deleted])
    git(repo,'checkout','-q','main')
    mainfiles={**deletedfiles,'CHANGELOG.md':'# v2\nMerged release\n# v1\nInitial\n'}
    mainline=commit('mainline',mainfiles,[deleted])
    git(repo,'merge','--no-ff','feature','-m','merge feature');merged=git(repo,'rev-parse','HEAD')
    labels['merge']=merged;states[merged]={**mainfiles,'feature.py':states[feature]['feature.py']};parents[merged]=[mainline,feature]
    git(repo,'tag','v-moving',base)
    expected={'states':states,'labels':labels,'parents':parents,'manifest':'same complete reachable Git history at selected revision; all tracked content generated independently'}
    dump('expected-state.json',expected)
    for s,files in states.items():
        check('git-tree:'+s,git(repo,'ls-tree','-r','--name-only',s).splitlines(),sorted(files))
        for p,t in files.items():check('git-bytes:'+s+':'+p,git(repo,'show',f'{s}:{p}')+'\n',t)
    cfg=RepoConfig(name='independent-recovery',path=str(repo),revisions=[merged],tag_pattern='^v')
    oldcfg=cfg.model_copy(update={'revisions':[base],'tag_pattern':None});dump('target-config.json',json.loads(cfg.model_dump_json()))
    def answers(name,revision=merged):
        q=RepoQuery(name,cfg.name,db=db)
        return norm({'resolve':q.resolve(revision),'symbols':q.symbols(revision,limit=200),'dependencies':q.dependencies(revision,'engine.run',hops=2,limit=200),'history':q.symbol_history('added.added',[base,added,deleted,merged]),'fix':q.fix_status(revision,edited),'notes':q.release_notes(revision,limit=200)})
    def normalized(name):
        g=db.select_graph(name)
        nodes=g.ro_query('MATCH (n) WHERE NOT n:ImportRun RETURN labels(n),properties(n)').result_set
        edges=g.ro_query('MATCH (a)-[e]->(b) WHERE NOT a:ImportRun AND NOT b:ImportRun RETURN labels(a),properties(a),type(e),properties(e),labels(b),properties(b)').result_set
        return {'nodes':sorted(canonical(x) for x in nodes),'edges':sorted(canonical(x) for x in edges),'answers':answers(name)}
    def duplicates(name):
        g=db.select_graph(name);result={}
        for label,key in [('Commit','sha'),('Blob','content_hash'),('Symbol','id'),('Tag','name')]:
            result[label]=g.ro_query(f'MATCH (n:{label}) WITH n.{key} AS identity,count(n) AS n WHERE n>1 RETURN identity,n').result_set
        result['HAS_FILE']=g.ro_query('MATCH (c:Commit)-[e:HAS_FILE]->() WITH c.sha AS sha,e.path AS path,count(e) AS n WHERE n>1 RETURN sha,path,n').result_set
        return result
    incremental=graph('incremental');stage_records=[]
    for label in ('base','add','edit','rename','delete','merge'):
        stagecfg=cfg.model_copy(update={'revisions':[labels[label]],'tag_pattern':None})
        report=I.index_repository(stagecfg,incremental,db=db)
        clean=graph('stage_'+label);I.index_repository(stagecfg,clean,db=db)
        # Compare all normalized graph facts; selected API answers pinned to the stage revision.
        old_answers=answers
        def stage_norm(name):
            n=normalized(name);n['answers']=old_answers(name,labels[label]);return n
        check('incremental-clean:'+label,stage_norm(incremental),stage_norm(clean))
        stage_records.append({'label':label,'report':dataclasses.asdict(report),'state':state(incremental)})
        if label!='base':check('content-reused:'+label,report.blobs_reused>0,True)
    before_tag=RepoQuery(incremental,cfg.name,db=db).resolve('v-moving')
    git(repo,'tag','-f','v-moving',merged)
    report=I.index_repository(cfg,incremental,db=db);clean=graph('clean');I.index_repository(cfg,clean,db=db)
    expected_final=normalized(clean);dump('clean-normalized.json',expected_final)
    check('moved-tag-target',RepoQuery(incremental,cfg.name,db=db).resolve('v-moving')[0],merged)
    check('moved-tag-clean-equivalent',normalized(incremental),expected_final)
    cached=RepoQuery(incremental,cfg.name,db=db);cached.symbols(merged)
    for marker,attribute in [('extractor','version'),('line-schema','LINE_SCHEMA')]:
        target=type(ADAPTERS['python']) if marker=='extractor' else I
        with patch.object(target,attribute,'independent-t4-'+marker):
            r=I.index_repository(cfg,incremental,db=db);c=graph('changed_'+marker);I.index_repository(cfg,c,db=db)
            check('changed-'+marker+'-clean-equivalent',normalized(incremental),normalized(c))
            check('changed-'+marker+'-reextracts',r.blobs_new>0,True)
            check('cached-query-refresh-'+marker,norm(cached.symbols(merged)),norm(RepoQuery(c,cfg.name,db=db).symbols(merged)))
            events.append({'case':marker,'report':dataclasses.asdict(r)})
    I.index_repository(cfg,incremental,db=db)
    graph_type=type(db.select_graph(clean));original_query=graph_type.query
    def mutates(c):return not c.startswith('CREATE INDEX') and any(t in c for t in (' SET ','CREATE ','MERGE ','DELETE '))
    capture_graph=graph('capture');I.index_repository(oldcfg,capture_graph,db=db);boundaries=[]
    def capture(self,cypher,*a,**kw):
        result=original_query(self,cypher,*a,**kw)
        if self.name==capture_graph and mutates(cypher):boundaries.append({'number':len(boundaries)+1,'cypher':cypher,'parameters':a[0] if a else kw.get('params')})
        return result
    with patch.object(type(ADAPTERS['python']),'version','independent-t4-extractor-epoch2'),patch.object(graph_type,'query',capture):I.index_repository(cfg,capture_graph,db=db)
    dump('persistence-boundaries.json',boundaries)
    fault_plan=[{'kind':'write','boundary':b['number'],'phase':phase} for b in boundaries for phase in ('before','after')]
    rng=random.Random(271828);random_points=[{'kind':'write','boundary':rng.randrange(1,len(boundaries)+1),'phase':rng.choice(['before','after']),'seed':271828,'random_trial':i} for i in range(5)]
    fault_plan+=random_points+[{'kind':k} for k in ('tags','commits','first_parent_changes','blob_batch','parse')]
    dump('fault-plan.json',fault_plan)
    fault_results=[]
    for number,point in enumerate(fault_plan):
        name=graph(f'fault_{number:03d}');I.index_repository(oldcfg,name,db=db);fired=[];count=[0]
        def inject_query(self,cypher,*a,**kw):
            eligible=self.name==name and mutates(cypher);count[0]+=int(eligible)
            hit=eligible and count[0]==point.get('boundary') and not fired
            if hit and point.get('phase')=='before':fired.append(cypher);raise InjectedFailure('before server write '+str(count[0]))
            value=original_query(self,cypher,*a,**kw)
            if hit and point.get('phase')=='after':fired.append(cypher);raise InjectedFailure('after server write '+str(count[0]))
            return value
        def fail(*a,**kw):fired.append(point['kind']);raise InjectedFailure(point['kind'])
        error=None;fault_start=time.monotonic()
        try:
            with patch.object(type(ADAPTERS['python']),'version','independent-t4-extractor-epoch2'):
                if point['kind']=='write':
                    with patch.object(graph_type,'query',inject_query):I.index_repository(cfg,name,db=db)
                else:
                    target=type(ADAPTERS['python']) if point['kind']=='parse' else I.GitRepo
                    method='extract' if point['kind']=='parse' else point['kind']
                    with patch.object(target,method,fail):I.index_repository(cfg,name,db=db)
        except Exception as exc:error=repr(exc)
        check(f'fault-fired:{number}',bool(fired),True)
        failure_state=state(name);q=RepoQuery(name,cfg.name,db=db);resolution=q.resolve(merged);page=q.symbols(merged)
        published=failure_state['repository'][0][0]
        check(f'incomplete-query-honesty:{number}',not page.items or published.get('status')=='COMPLETE',True)
        retry_start=time.monotonic();receipt=I.index_repository(cfg,name,db=db);recovered=normalized(name)
        check(f'recovered-equivalent:{number}',recovered,expected_final)
        check(f'no-duplicates:{number}',any(duplicates(name).values()),False)
        fault_results.append({'point':point,'fired':fired,'error':error,'failed_state':failure_state,'resolution_after_fault':norm(resolution),'symbols_after_fault':norm(page),'retry_report':dataclasses.asdict(receipt),'recovery_seconds':time.monotonic()-retry_start,'total_seconds':time.monotonic()-fault_start,'normalized_sha256':digest(canonical(recovered).encode())})
    dump('fault-results.json',fault_results)
    # Real process exit after destructive persistence, then a new process retries.
    crash_graph=graph('process_restart');I.index_repository(oldcfg,crash_graph,db=db)
    cmd=[sys.executable,str(Path(__file__).resolve()),'--port',str(args.port),'--graph',crash_graph,'--child','crash']
    p=subprocess.run(cmd,capture_output=True,text=True,timeout=15);check('process-crash-exit',p.returncode,73)
    check('process-crash-marker',(OUT/'process-crash-marker').exists(),True)
    crash_state=state(crash_graph);check('process-crash-rejects-query',bool(RepoQuery(crash_graph,cfg.name,db=db).symbols(merged).items),False)
    deadline=time.monotonic()+5
    while db.connection.exists('rw:repo-import:'+crash_graph) and time.monotonic()<deadline:time.sleep(.03)
    retry_cmd=cmd[:-1]+['retry'];p2=subprocess.run(retry_cmd,capture_output=True,text=True,timeout=15)
    check('new-process-retry-success',p2.returncode,0);check('new-process-recovered-equivalent',normalized(crash_graph),expected_final)
    events.append({'case':'process_restart','crash_command':cmd,'crash_exit':p.returncode,'crash_stdout':p.stdout,'crash_stderr':p.stderr,'state_after_crash':crash_state,'retry_command':retry_cmd,'retry_exit':p2.returncode,'retry_stdout':p2.stdout,'retry_stderr':p2.stderr,'test_lease_seconds':2})
    # Hold a real writer at a persistence boundary; concurrent writer/query must reject.
    concurrent_graph=graph('concurrent');I.index_repository(oldcfg,concurrent_graph,db=db);entered=threading.Event();release=threading.Event()
    original_write=I._write
    def pause_write(g,cypher,rows):
        if 'CREATE (c)-[:HAS_FILE' in cypher and rows and not entered.is_set():entered.set();release.wait(5)
        return original_write(g,cypher,rows)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool,patch.object(I,'_write',pause_write):
        future=pool.submit(I.index_repository,cfg,concurrent_graph,db)
        check('concurrent-writer-entered',entered.wait(5),True)
        qpage=RepoQuery(concurrent_graph,cfg.name,db=db).symbols(merged)
        check('concurrent-query-rejects-partial',bool(qpage.items),False)
        try:I.index_repository(cfg,concurrent_graph,db=db);second_error=None
        except Exception as exc:second_error=repr(exc)
        check('concurrent-writer-rejected',second_error is not None and 'already in progress' in second_error,True)
        events.append({'case':'concurrent','query':norm(qpage),'second_writer_error':second_error,'in_progress_state':state(concurrent_graph)})
        release.set();future.result(timeout=10)
    check('concurrent-final-equivalent',normalized(concurrent_graph),expected_final)
    # A disabled owned database must visibly fail and then recover after restart.
    availability=[]
    for command in (['docker','pause','rw-index-recovery-20261018'],):
        pr=subprocess.run(command,capture_output=True,text=True);availability.append({'argv':command,'exit':pr.returncode,'stdout':pr.stdout,'stderr':pr.stderr})
    try:
        unavailable_db=G.connect(port=args.port,socket_timeout=.3)
        try:RepoQuery(clean,cfg.name,db=unavailable_db).symbols(merged);db_error=None
        except Exception as exc:db_error=repr(exc)
        check('database-unavailable-visible-failure',db_error is not None,True)
    finally:
        command=['docker','unpause','rw-index-recovery-20261018'];pr=subprocess.run(command,capture_output=True,text=True);availability.append({'argv':command,'exit':pr.returncode,'stdout':pr.stdout,'stderr':pr.stderr})
    check('database-returned-query-equivalent',normalized(clean),expected_final)
    events.append({'case':'database_unavailable','commands':availability,'error':db_error})
    dump('events.json',events);dump('stage-results.json',stage_records)
    dump('results.json',{'checks':checks,'failures':failures,'source_unchanged':pin()['all_match'],'seconds':time.monotonic()-start,'fault_cases':len(fault_plan),'persistence_boundaries':len(boundaries),'graphs':graphs,'normalization_excluded_keys':sorted(DROP),'normalization_excluded_entities':['ImportRun and incident INDEXED edges: operational import attempts; generations retained in receipts']})
    dump('source-after.json',pin())
    for name in graphs:
        try:db.select_graph(name).delete()
        except Exception as exc:events.append({'cleanup_error':name,'error':repr(exc)})
    dump('graph-cleanup.json',{'graphs':graphs,'remaining_graphs':db.list_graphs()})
    print(json.dumps({'checks':len(checks),'failures':len(failures),'fault_cases':len(fault_plan),'boundaries':len(boundaries),'seconds':time.monotonic()-start}),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,required=True);parser.add_argument('--graph');parser.add_argument('--child',choices=['crash','retry']);args=parser.parse_args()
    assert args.port not in (6379,6382)
    if args.child:child(args)
    else:
        try:main(args)
        except BaseException:
            dump('fatal-error.json',{'error':traceback.format_exc(),'source_pin':pin()});raise
