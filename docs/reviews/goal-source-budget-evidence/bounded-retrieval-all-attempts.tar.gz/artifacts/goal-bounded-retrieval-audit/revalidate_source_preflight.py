"""Independent narrow revalidation of the 199-file source-preflight candidate."""
from __future__ import annotations
import argparse,dataclasses,hashlib,json,os,platform,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(ROOT/'src'))
IMAGE='falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'
PIN=ROOT/'artifacts/goal-source-preflight/implementation-manifest.json'
COMMANDS=[];TRACES=[];GIT=[];CASES=[];started=time.monotonic()
def clean(v):
 if dataclasses.is_dataclass(v):return clean(dataclasses.asdict(v))
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [clean(x) for x in v]
 return v
def save(n,v):(OUT/n).write_text(json.dumps(clean(v),indent=2,sort_keys=True)+'\n')
def cmd(argv,**kw):
 t=time.monotonic();r=subprocess.run(argv,text=True,capture_output=True,**kw)
 COMMANDS.append(dict(argv=argv,exit_code=r.returncode,stdout=r.stdout,stderr=r.stderr,seconds=time.monotonic()-t))
 r.check_returncode();return r.stdout.strip()
def hashes():
 # Do not open held-out task/oracle data even for hashing.
 files=sorted((ROOT/'src').rglob('*.py'))+sorted((ROOT/'tests').rglob('*.py'))+[PIN]
 return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
def case(n,fn):
 mark=len(GIT);t=time.monotonic()
 try:r=dict(name=n,status='PASS',detail=clean(fn()))
 except Exception as exc:r=dict(name=n,status='FAIL',error=repr(exc),traceback=traceback.format_exc())
 r.update(seconds=time.monotonic()-t,git_trace_start=mark,git_trace_end=len(GIT));CASES.append(r);save('cases.json',CASES)
 print(n,r['status'],flush=True)
before=hashes();save('source-before.json',before)
manifest=json.loads(PIN.read_text());safe_matches={}
for path,actual in before.items():
 if path in manifest['files']:safe_matches[path]=dict(expected=manifest['files'][path],actual=actual,match=manifest['files'][path]==actual)
assert all(v['match'] for v in safe_matches.values()),'safe implementation/public-test files differ from candidate pin'
save('candidate-pin-verification.json',dict(pin=str(PIN.relative_to(ROOT)),pin_sha256=hashlib.sha256(PIN.read_bytes()).hexdigest(),
 declared_files=len(manifest['files']),classification=manifest['classification'],safe_subset=safe_matches,
 heldout_files_not_opened=True,full_manifest_content_rehash=False,historical_198_pin_is_not_current=True))
save('configuration.json',dict(image=IMAGE,python=sys.executable,version=sys.version,platform=platform.platform(),cpus=os.cpu_count(),
 script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_size=159984,provider_calls=0,
 instrumentation='GitRepo._proc observation delegates real commands unchanged; counts payload stdout in query/retrieval scopes only; indexing excluded'))
container=None
try:
 container=cmd(['docker','run','-d','--rm','--name','rw-t5-preflight-'+str(os.getpid()),'--memory','1g','--cpus','2','-p','127.0.0.1::6379',IMAGE])
 port=int(cmd(['docker','port',container,'6379/tcp']).split(':')[-1]);assert port not in (6379,6382)
 os.environ['RW_FALKORDB_PORT']=str(port);os.environ['RW_FALKORDB_HOST']='127.0.0.1'
 save('container.json',json.loads(cmd(['docker','inspect',container])))
 from rw import graph as G
 from rw.repo.git import GitRepo
 from rw.repo.config import RepoConfig
 from rw.repo.index import index_repository
 from rw.repo.query import RepoQuery
 from rw.repo.budget import BudgetExhausted,ReadLimits,ReadBudget,read_scope
 from rw.repo.investigate import investigate
 for _ in range(100):
  try:G.connect().select_graph('rw_t5_preflight_ready').ro_query('RETURN 1');break
  except Exception:time.sleep(.05)
 p=OUT/'synthetic';p.mkdir()
 def git(*a):return cmd(['git','-c','user.name=T5 independent audit','-c','user.email=t5@example.invalid','-c','commit.gpgsign=false','-C',str(p),*a],env={**os.environ,'GIT_AUTHOR_DATE':'2026-01-01T00:00:00Z','GIT_COMMITTER_DATE':'2026-01-01T00:00:00Z'})
 git('init','-q','-b','main')
 old=b'#'+b'x'*(159984-len(b'#\ndef fixed():\n    return 1\n'))+b'\ndef fixed():\n    return 1\n'
 assert len(old)==159984
 (p/'a.py').write_bytes(old);git('add','-A');git('commit','-qm','independent original159984-byte source')
 parent=git('rev-parse','HEAD');old_oid=git('rev-parse','HEAD:a.py')
 new=old.replace(b'return 1',b'return 22');(p/'a.py').write_bytes(new);git('add','-A');git('commit','-qm','changed larger source')
 child=git('rev-parse','HEAD');new_oid=git('rev-parse','HEAD:a.py')
 save('expected-state.json',dict(parent=parent,child=child,old_oid=old_oid,new_oid=new_oid,old_bytes=len(old),new_bytes=len(new),
  reserved_patch_inputs=len(old)+len(new),old_sha256=hashlib.sha256(old).hexdigest(),new_sha256=hashlib.sha256(new).hexdigest(),
  parent_tree=git('ls-tree','-r',parent),child_tree=git('ls-tree','-r',child)))
 cfg=RepoConfig(name='t5-source-revalidation',path=str(p),revisions=[parent,child]);graph='rw_t5_source_revalidation'
 report=index_repository(cfg,graph);save('index-report.json',report)
 original_proc=GitRepo._proc
 def observed(self,*argv,**kw):
  t=time.monotonic();event=dict(args=list(argv),stdin_bytes=len(kw.get('stdin') or b''))
  try:
   result=original_proc(self,*argv,**kw)
   payload=(argv[:2]==('cat-file','blob') or (argv and argv[0]=='diff-tree' and '-p' in argv))
   event.update(exit_code=result.returncode,stdout_bytes=len(result.stdout),payload_command=payload,
    source_or_patch_payload_stdout_bytes=len(result.stdout) if payload else 0,
    stdout_sha256=hashlib.sha256(result.stdout).hexdigest())
   if not payload:event['metadata_stdout']=result.stdout.decode('utf-8','replace')
   return result
  except Exception as exc:event['error']=repr(exc);raise
  finally:event['seconds']=time.monotonic()-t;GIT.append(event)
 GitRepo._proc=observed
 def query_reject():
  mark=len(GIT);q=RepoQuery(graph,cfg.name,trace=TRACES,limits=ReadLimits(source_bytes=1))
  page=q.symbols(parent,limit=1);TRACES.append(dict(kind='strict-source-query',page=clean(page)))
  budget=page.coverage['budget'];payload=sum(e.get('source_or_patch_payload_stdout_bytes',0) for e in GIT[mark:])
  assert budget['source_bytes']==0 and payload==0
  assert page.truncated and page.coverage.get('complete') is False and not page.items
  assert any(g.kind=='RETRIEVAL_BUDGET_EXHAUSTED' for g in page.coverage['gaps'])
  return dict(limit=1,source_bytes_counter=budget['source_bytes'],payload_stdout_bytes=payload,actual_blob_payload_commands=sum(e.get('payload_command',False) for e in GIT[mark:]),budget=budget)
 case('query-original159984-byte-failure-now-rejected-before-payload',query_reject)
 def investigate_reject():
  mark=len(GIT);r=investigate(cfg.name,parent,'What does a.fixed depend on?',config=cfg.model_copy(update={'query_max_source_bytes':1}),graph_name=graph)
  TRACES.append(dict(kind='strict-source-investigation',result=clean(r)))
  assert not r.answer and not r.findings and not r.facts and not r.citations and r.unresolved
  assert r.retrieval_budget['source_bytes']==0 and sum(e.get('source_or_patch_payload_stdout_bytes',0) for e in GIT[mark:])==0
  return dict(no_answer_or_findings=True,source_bytes_counter=0,payload_stdout_bytes=0,gaps=[g.kind for g in r.gaps])
 case('investigation-source-exhaustion-withholds-answer',investigate_reject)
 def exact_fit_query():
  mark=len(GIT)
  with read_scope(ReadLimits(source_bytes=len(old))) as b:
   page=RepoQuery(graph,cfg.name,trace=TRACES).symbols(parent,limit=200)
   snap=b.snapshot()
  TRACES.append(dict(kind='exact-fit-query',page=clean(page),budget=snap))
  payload=sum(e.get('source_or_patch_payload_stdout_bytes',0) for e in GIT[mark:])
  assert [x.qualname for x in page.items]==['a','a.fixed'] and not page.truncated
  assert snap['source_bytes']==len(old) and payload==len(old)
  return dict(limit=len(old),source_bytes_counter=snap['source_bytes'],payload_stdout_bytes=payload,logical_results=['a','a.fixed'])
 case('exact-fit-query-source-payload-and-counter',exact_fit_query)
 g=GitRepo(p)
 for operation in ['patch','patch_id']:
  def rejected_patch(operation=operation):
   mark=len(GIT)
   with read_scope(ReadLimits(source_bytes=1)) as b:
    try:g.patch(parent,child) if operation=='patch' else g.patch_id(child)
    except BudgetExhausted as exc:assert exc.resource=='source_bytes'
    else:raise AssertionError('oversized patch accepted')
    snap=b.snapshot()
   payload=sum(e.get('source_or_patch_payload_stdout_bytes',0) for e in GIT[mark:])
   assert snap['source_bytes']==0 and payload==0 and not any(e.get('payload_command') for e in GIT[mark:])
   return dict(operation=operation,limit=1,counter=0,patch_payload_stdout_bytes=payload,patch_generation_commands=0)
  case(operation+'-declined-before-payload',rejected_patch)
  def fitting_patch(operation=operation):
   expected=g.patch(parent,child) if operation=='patch' else g.patch_id(child)
   mark=len(GIT);total=len(old)+len(new)
   with read_scope(ReadLimits(source_bytes=total)) as b:
    actual=g.patch(parent,child) if operation=='patch' else g.patch_id(child)
    assert actual==expected and b.source_bytes==total
    once=b.source_bytes
    try:g.patch(parent,child) if operation=='patch' else g.patch_id(child)
    except BudgetExhausted:pass
    else:raise AssertionError('cumulative source reservation ignored')
    assert b.source_bytes==once
   return dict(operation=operation,limit=total,reserved_source_bytes=once,actual_patch_payload_stdout_bytes=sum(e.get('source_or_patch_payload_stdout_bytes',0) for e in GIT[mark:]),repeated_operation_rejected=True)
  case(operation+'-exact-fit-and-cumulative-reservation',fitting_patch)
 def declined_charge():
  b=ReadBudget(ReadLimits(source_bytes=4));b.consume_source(2)
  try:b.consume_source(3)
  except BudgetExhausted:pass
  else:raise AssertionError('oversized charge accepted')
  assert b.source_bytes==2
  return dict(limit=4,before=2,declined=3,after=2)
 case('declined-counter-charge-preserved',declined_charge)
 GitRepo._proc=original_proc
except Exception as exc:CASES.append(dict(name='harness',status='FAIL',error=repr(exc),traceback=traceback.format_exc()))
finally:
 save('cases.json',CASES);save('git-traces.json',GIT);save('graph-and-page-traces.json',TRACES)
 if container:
  try:
   save('final-stats.json',cmd(['docker','stats','--no-stream','--format','{{json .}}',container]))
   cmd(['docker','rm','-f',container]);save('cleanup.json',dict(removed_container=container,remaining_own=cmd(['docker','ps','-a','--filter','name=rw-t5-preflight-','--format','{{.ID}} {{.Names}}'])))
  except Exception as exc:save('cleanup-error.json',dict(error=repr(exc)))
 after=hashes();save('source-after.json',after);save('commands.json',COMMANDS)
 save('summary.json',dict(passed=sum(c['status']=='PASS' for c in CASES),failed=sum(c['status']=='FAIL' for c in CASES),source_unchanged=before==after,
  elapsed_seconds=time.monotonic()-started,pin=str(PIN.relative_to(ROOT)),declared_pin_files=len(manifest['files']),full_T5_claim=False,
  original_failure_preserved='../run-004/strict-source-bound.json',provider_calls=0,payload_measurement='Real Git child stdout payload bytes; no OS-level filesystem/disk-read attribution'))
 print(json.dumps(json.loads((OUT/'summary.json').read_text())),flush=True)
