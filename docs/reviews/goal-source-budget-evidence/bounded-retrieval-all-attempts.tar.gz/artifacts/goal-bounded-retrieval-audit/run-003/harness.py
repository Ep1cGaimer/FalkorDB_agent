"""Production 10000-edge boundary + strict-bound audit. Synthetic data only."""
from __future__ import annotations
import argparse, base64, dataclasses, gzip, hashlib, json, os, platform, subprocess, sys, time, traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
parser.add_argument('--full-union',action='store_true')
args=parser.parse_args()
OUT=args.output.resolve();OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(ROOT/'src'));sys.path.insert(0,str(ROOT))
COMMANDS=[];CASES=[];TRACES=[];EXPECTED={};start=time.monotonic()
IMAGE='falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'

def clean(v):
    if dataclasses.is_dataclass(v):return clean(dataclasses.asdict(v))
    if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [clean(x) for x in v]
    return v
def save(name,value): (OUT/name).write_text(json.dumps(clean(value),indent=2,sort_keys=True)+'\n')
def cmd(argv,**kw):
    r=subprocess.run(argv,text=True,capture_output=True,**kw)
    COMMANDS.append(dict(argv=argv,stdout=r.stdout,stderr=r.stderr,exit_code=r.returncode))
    r.check_returncode();return r.stdout.strip()
def hashes():
    files=sorted((ROOT/'src').rglob('*.py'))+sorted((ROOT/'tests').rglob('*.py'))
    files+=[ROOT/'docs/reviews/goal-hackathon-delivery-evidence/implementation-manifest.json']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
def case(name,fn):
    started=time.monotonic()
    try:detail=fn();r=dict(name=name,status='PASS',detail=clean(detail))
    except Exception as exc:r=dict(name=name,status='FAIL',error=repr(exc),traceback=traceback.format_exc())
    r['seconds']=time.monotonic()-started;CASES.append(r);save('cases.json',CASES);print(name,r['status'],flush=True)
def git(p,*args):
    return cmd(['git','-c','user.name=T5 audit','-c','user.email=t5@example.invalid',
                '-c','commit.gpgsign=false','-C',str(p),*args],env={**os.environ,
                'GIT_AUTHOR_DATE':'2026-01-01T00:00:00Z','GIT_COMMITTER_DATE':'2026-01-01T00:00:00Z'})

before=hashes();save('source-before.json',before)
save('configuration.json',dict(image=IMAGE,interpreter=sys.executable,version=sys.version,
    machine=platform.platform(),cpus=os.cpu_count(),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    production_walk_edges=10000,configured_page_limit=200,rows=250000,seconds=120,source_bytes=67108864,
    expected_edges='Explicit imports ext00000..ext{N-1}; independent literal list, not graph output',
    scope='Complete union of served pages plus explicit missing-edge comparison' if args.full_union else 'First-page cut metadata only',
    token_scope='Local meter preflight counter only: fake count method, generation method forbidden; no provider/model outputs'))
container=None
try:
    container=cmd(['docker','run','-d','--rm','--name','rw-t5-extended-'+str(os.getpid()),
                   '--cpus','2','--memory','1g','-p','127.0.0.1::6379',IMAGE])
    port=int(cmd(['docker','port',container,'6379/tcp']).split(':')[-1]);assert port not in [6379,6382]
    os.environ['RW_FALKORDB_PORT']=str(port);os.environ['RW_FALKORDB_HOST']='127.0.0.1'
    save('container.json',json.loads(cmd(['docker','inspect',container])))
    from rw import graph as G
    from rw.repo.config import RepoConfig
    from rw.repo.index import index_repository
    from rw.repo.query import RepoQuery
    from rw.repo.budget import ReadLimits
    from rw.repo.investigate import investigate
    for _ in range(100):
        try:G.connect().select_graph('rw_t5_ready').ro_query('RETURN 1');break
        except Exception:time.sleep(.05)
    for n in [9999,10000,10001]:
        def boundary(n=n):
            p=OUT/f'repo-{n}';p.mkdir();git(p,'init','-q','-b','main')
            # One physical source line keeps citation hashing bounded even for 10000 edges.
            (p/'wide.py').write_text(';'.join(f'import ext{i:05d}' for i in range(n))+'\n')
            git(p,'add','-A');git(p,'commit','-qm',f'production edge boundary {n}')
            sha=git(p,'rev-parse','HEAD'); tree=git(p,'ls-tree','-r','HEAD')
            expected=[['wide',f'ext{i:05d}','IMPORTS'] for i in range(n)]
            EXPECTED[str(n)]=dict(commit=sha,tree=tree,edges=expected);save('expected-state.json',EXPECTED)
            cfg=RepoConfig(name=f'edges-{n}',path=str(p),revisions=['HEAD']);graph=f'rw_t5_edges_{n}'
            report=index_repository(cfg,graph);TRACES.append(dict(kind='index',report=clean(report)))
            q=RepoQuery(graph,cfg.name,trace=TRACES)
            page=q.dependencies(sha,'wide',hops=1,limit=200)
            TRACES.append(dict(kind='production-edge-first-page',n=n,page=clean(page)))
            actual=[[i.source,i.target,i.kind] for i in page.items]
            assert actual==expected[:200]
            assert page.coverage['total']==min(n,10000)
            assert page.coverage['frontier_truncated']==(n>10000)
            assert ('TRUNCATED' in [g.kind for g in page.coverage['gaps']])==(n>10000)
            assert page.truncated and page.next_cursor
            page_count=1
            if args.full_union:
                while True:
                    # Preserve every query, cursor, and row without retaining repeated snapshots in memory.
                    with gzip.open(OUT/'full-traces.jsonl.gz','at') as stream:
                        for event in TRACES:stream.write(json.dumps(clean(event),sort_keys=True)+'\n')
                    TRACES.clear()
                    if page.next_cursor is None:break
                    token=page.next_cursor
                    page=q.dependencies(sha,'wide',hops=1,limit=200,cursor=token)
                    TRACES.append(dict(kind='production-edge-page',n=n,input_cursor=token,page=clean(page)))
                    actual.extend([[i.source,i.target,i.kind] for i in page.items]);page_count+=1
                    assert len(page.items)<=200 and page.coverage['frontier_truncated']==(n>10000)
                assert actual==expected[:10000]
                assert len(actual)==len(set(tuple(i) for i in actual))
                assert page.next_cursor is None
                if n>10000:assert any(g.kind=='TRUNCATED' for g in page.coverage['gaps'])
                else:assert len(actual)==len(expected)
            if n==10001:
                finding=investigate(cfg.name,sha,'What does wide depend on?',config=cfg,graph_name=graph)
                TRACES.append(dict(kind='production-cut-investigation',result=clean(finding)))
                assert any(g.kind=='TRUNCATED' for g in finding.gaps)
                assert not (finding.answer and 'no depend' in finding.answer.lower())
            return dict(edges=n,page_returned=200,collected_total=page.coverage['total'],
                        frontier_truncated=page.coverage['frontier_truncated'],full_union_checked=args.full_union,
                        pages=page_count,union_returned=len(actual),independent_full_graph=n,
                        omitted_but_explicitly_reported=max(0,n-10000),final_page_truncated=page.truncated)
        case(f'production-edge-cap-{n}',boundary)
    def strict_source_bound():
        # Distinguish visible exhaustion (already passed) from respecting a hard byte cap.
        page=RepoQuery('rw_t5_edges_9999','edges-9999',trace=TRACES,limits=ReadLimits(source_bytes=1)).symbols('HEAD')
        TRACES.append(dict(kind='strict-source-bound',page=clean(page)))
        budget=page.coverage['budget'];save('strict-source-bound.json',dict(configured=1,consumed=budget['source_bytes'],page=clean(page)))
        assert budget['source_bytes']<=1,f"hard source-byte cap exceeded: {budget['source_bytes']} > 1; exhaustion visible but post-read"
    case('strict-source-byte-hard-bound',strict_source_bound)
    def token_preflight():
        from evals.confirmatory.gemini_meter import MeteredModel,ModelLimits,ModelFailure,Journal
        class CounterOnly:
            model='local-fake-counter-no-generation'
            def __init__(self):self.count_calls=0;self.generate_calls=0
            def count(self,request,timeout):self.count_calls+=1;return {'totalTokens':11}
            def generate(self,*args):self.generate_calls+=1;raise AssertionError('generation forbidden')
        api=CounterOnly();p=OUT/'token-preflight'
        model=MeteredModel(api,Journal(p),ModelLimits(input_tokens=10,input_reserve=0,output_tokens=1,per_call_output=1))
        try:model.ask('local counter probe',[],phase='retrieval')
        except ModelFailure as exc:code=exc.code
        else:raise AssertionError('token exhaustion not enforced')
        assert code=='MODEL_INPUT_BUDGET_EXHAUSTED' and api.generate_calls==0 and api.count_calls==1
        return dict(component_only=True,code=code,count_calls=1,provider_calls=0,generation_calls=0,no_model_outputs=True)
    case('token-input-preflight-component',token_preflight)
except Exception as exc:
    CASES.append(dict(name='harness',status='FAIL',error=repr(exc),traceback=traceback.format_exc()))
finally:
    save('cases.json',CASES);save('traces.json',TRACES)
    if container:
        try:
            save('final-stats.json',cmd(['docker','stats','--no-stream','--format','{{json .}}',container]))
            cmd(['docker','rm','-f',container]);save('cleanup.json',dict(removed_container=container,
                remaining_own=cmd(['docker','ps','-a','--filter','name=rw-t5-extended-','--format','{{.ID}} {{.Names}}'])))
        except Exception as exc:save('cleanup-error.json',dict(error=repr(exc)))
    after=hashes();save('source-after.json',after);save('commands.json',COMMANDS)
    save('summary.json',dict(passed=sum(c['status']=='PASS' for c in CASES),failed=sum(c['status']=='FAIL' for c in CASES),
         source_unchanged=before==after,elapsed_seconds=time.monotonic()-start,full_T5_claim=False))
    print(json.dumps(json.loads((OUT/'summary.json').read_text())),flush=True)
