"""Synthetic-only independent T5 audit. No provider, sealed-data, or demo access."""
from __future__ import annotations
import base64, dataclasses, hashlib, json, os, platform, subprocess, sys, time, traceback
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
IMAGE = 'falkordb/falkordb@sha256:107455e862a824e45e8e9f5a7fbfdf5e00a08b14e13eae2577c72fd9e3f59ba6'
COMMANDS, CASES, TRACES, EXPECTED = [], [], [], {}
START = time.monotonic()
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
sys.path.insert(0, str(ROOT / 'src'))

def clean(v):
    if dataclasses.is_dataclass(v): return clean(dataclasses.asdict(v))
    if isinstance(v, dict): return {str(k):clean(x) for k,x in v.items()}
    if isinstance(v, (list,tuple,set)): return [clean(x) for x in v]
    if isinstance(v, Path): return str(v)
    return v

def save(name, value):
    (OUT / name).write_text(json.dumps(clean(value), indent=2, sort_keys=True) + '\n')

def cmd(args, **kw):
    start = time.monotonic()
    result = subprocess.run(args, text=True, capture_output=True, **kw)
    COMMANDS.append(dict(argv=args, cwd=str(kw.get('cwd', ROOT)), exit_code=result.returncode,
                         stdout=result.stdout, stderr=result.stderr, seconds=time.monotonic()-start))
    result.check_returncode()
    return result.stdout.strip()

def hashes():
    # Only implementation and existing public tests: never open held-out task/oracle data.
    paths = sorted((ROOT/'src').rglob('*.py')) + sorted((ROOT/'tests').rglob('*.py'))
    paths += [ROOT/'remquirements-v1.md', ROOT/'docs/reviews/goal-hackathon-delivery-evidence/implementation-manifest.json']
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def case(name, fn):
    start = time.monotonic()
    try:
        detail = fn()
        CASES.append(dict(name=name, status='PASS', seconds=time.monotonic()-start, detail=clean(detail)))
    except Exception as exc:
        CASES.append(dict(name=name, status='FAIL', seconds=time.monotonic()-start,
                          error=repr(exc), traceback=traceback.format_exc()))
    save('cases.json', CASES)
    print(name, CASES[-1]['status'], flush=True)

def git(path,*args):
    env = {**os.environ, 'GIT_AUTHOR_DATE':'2026-01-01T00:00:00Z', 'GIT_COMMITTER_DATE':'2026-01-01T00:00:00Z'}
    return cmd(['git','-c','user.name=T5 audit','-c','user.email=t5@example.invalid',
                '-c','commit.gpgsign=false','-c','tag.gpgsign=false','-C',str(path),*args],env=env)

def commit(path, files, message):
    for name, text in files.items():
        p=path/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text)
    git(path,'add','-A'); git(path,'commit','-qm',message)
    sha=git(path,'rev-parse','HEAD')
    EXPECTED.setdefault('git_trees',{})[sha]=git(path,'ls-tree','-r',sha)
    save('expected-state.json',EXPECTED)
    return sha

def repo(name, files, revisions=None):
    path=OUT/'synthetic'/name; path.mkdir(parents=True)
    git(path,'init','-q','-b','main')
    sha=commit(path,files,'synthetic '+name)
    cfg=RepoConfig(name=name,path=str(path),revisions=revisions or ['HEAD'])
    graph='rw_t5_'+name.replace('-','_')
    report=index_repository(cfg,graph)
    TRACES.append(dict(kind='index', name=name, report=clean(report)))
    return path,cfg,graph,sha

def query(cfg,graph,**kw):
    return RepoQuery(graph,cfg.name,trace=TRACES,**kw)

def pages(q, method, *args, limit=10, **kw):
    actual=[]; records=[]; cursor=None
    for n in range(100):
        p=getattr(q,method)(*args,limit=limit,cursor=cursor,**kw)
        r=dict(kind='page',method=method,args=args,kwargs=kw,limit=limit,input_cursor=cursor,page=clean(p))
        TRACES.append(r); records.append(r)
        assert len(p.items)<=limit
        assert p.coverage.get('returned',len(p.items))==len(p.items)
        actual.extend(p.items)
        if not p.next_cursor: break
        assert p.truncated, 'continuation not reported as truncation'
        cursor=p.next_cursor
    else: raise AssertionError('pagination did not terminate')
    return actual,records

def reject(q,method,*args,**kw):
    try:
        result=getattr(q,method)(*args,**kw)
    except ValueError as exc:
        TRACES.append(dict(kind='rejected',method=method,args=args,kwargs=kw,error=repr(exc)))
        return 'ValueError'
    TRACES.append(dict(kind='rejection-response',method=method,args=args,kwargs=kw,page=clean(result)))
    assert any(g.kind=='INVALID_CURSOR' for g in result.coverage.get('gaps',[])),clean(result)
    return 'INVALID_CURSOR'

before=hashes(); save('source-before.json',before)
save('configuration.json',dict(image=IMAGE,python=sys.executable,python_version=sys.version,
    platform=platform.platform(),machine=platform.machine(),processor=platform.processor(),
    cpu_count=os.cpu_count(),working_directory=str(ROOT),started_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
    limits=dict(page_cap=200,hop_cap=5,production_walk_edge_cap=10000),
    boundaries=dict(rows=[0,1,9,10,11,35],page_cap=10,hops=[0,1,2,3,4,5,6]),
    oracle='Literal source generator and independently implemented adjacency BFS; Git ls-tree/rev-list',
    provider_calls=0,sealed_inputs_opened=False))
container=None
try:
    name='rw-t5-audit-'+str(os.getpid())
    container=cmd(['docker','run','-d','--rm','--name',name,'--memory','1g','--cpus','2',
                   '-p','127.0.0.1::6379',IMAGE])
    port=int(cmd(['docker','port',container,'6379/tcp']).split(':')[-1])
    assert port not in [6379,6382]
    os.environ['RW_FALKORDB_HOST']='127.0.0.1'; os.environ['RW_FALKORDB_PORT']=str(port)
    save('container.json',json.loads(cmd(['docker','inspect',container])))
    from rw import graph as G
    from rw.repo.config import RepoConfig
    from rw.repo.index import index_repository
    from rw.repo.query import RepoQuery
    from rw.repo.budget import ReadLimits
    from rw.repo.investigate import investigate
    import rw.repo.query as Q
    for _ in range(100):
        try:
            G.connect().connection.ping(); break
        except Exception:
            time.sleep(.05)

    for count in [0,1,9,10,11,35]:
        def boundary(count=count):
            text=''.join(f'def f{i:03d}():\n    return {i}\n\n' for i in range(max(0,count-1)))
            files={'a.py':text} if count else {'README.txt':'No extractable symbols\n'}
            expected=['a']+[f'a.f{i:03d}' for i in range(count-1)] if count else []
            EXPECTED['rows-'+str(count)]=expected; save('expected-state.json',EXPECTED)
            _,cfg,graph,sha=repo('rows-'+str(count),files)
            items,records=pages(query(cfg,graph),'symbols',sha)
            actual=[i.qualname for i in items]
            assert actual==expected and len(actual)==len(set(actual))
            again,_=pages(query(cfg,graph),'symbols',sha)
            assert clean(items)==clean(again),'ordering/citations nondeterministic'
            return dict(count=count,pages=len(records),final_page_size=len(records[-1]['page']['items']),
                        final_evidence=expected[-1:] if expected else [],exact_enumeration=True)
        case('row-boundary-'+str(count),boundary)

    adjacency={0:[1,2,3,4],1:[0],2:[5],3:[5],4:[],5:[6],6:[7],7:[8],8:[]}
    text=''.join(f'def f{i}():\n'+(''.join(f'    f{j}()\n' for j in js) or '    pass\n')+'\n' for i,js in adjacency.items())
    path,cfg,graph,sha=repo('cycles',{'a.py':text,'other.py':'def f0():\n    pass\n'})
    def oracle(hops,reverse=False):
        work=deque([(0,0)]); seen={0}; result=[]; edges=set()
        lookup={i:[] for i in adjacency}
        for source,targets in adjacency.items():
            for target in targets: lookup[target if reverse else source].append((source,target))
        while work:
            node,depth=work.popleft()
            if depth>=hops: continue
            for source,target in sorted(lookup[node]):
                if (source,target) in edges: continue
                edges.add((source,target)); result.append([f'a.f{source}',f'a.f{target}','CALLS',depth+1])
                nxt=source if reverse else target
                if nxt not in seen: seen.add(nxt); work.append((nxt,depth+1))
        return result
    for reverse in [False,True]:
        for hops in [1,2,3,4,5]:
            expected=oracle(hops,reverse); EXPECTED[f'bfs-{reverse}-{hops}']=expected; save('expected-state.json',EXPECTED)
            def traversal(hops=hops,reverse=reverse,expected=expected):
                items,records=pages(query(cfg,graph),'dependents' if reverse else 'dependencies',sha,'a.f0',hops=hops,limit=2)
                actual=[[i.source,i.target,i.kind,i.hops] for i in items]
                assert actual==expected,(actual,expected)
                assert len(actual)==len(set(tuple(x[:3]) for x in actual))
                return dict(hops=hops,reverse=reverse,count=len(actual),pages=len(records),final_page=actual[-2:],exact_enumeration=True)
            case(f'bfs-{reverse}-{hops}',traversal)
    for hops in [0,6]:
        case('invalid-hop-'+str(hops),lambda hops=hops:reject(query(cfg,graph),'dependencies',sha,'a.f0',hops=hops))

    def empty_and_names():
        p=query(cfg,graph).dependencies(sha,'a.f8',limit=2); TRACES.append(dict(kind='empty-dependencies',page=clean(p)))
        assert not p.items and p.next_cursor is None and not p.truncated
        items,_=pages(query(cfg,graph),'symbols',sha,name='f0',limit=1)
        assert [i.qualname for i in items]==['a.f0','other.f0']
        return dict(empty_dependency_page=True,repeated_leaf_names=['a.f0','other.f0'])
    case('empty-pages-repeated-names',empty_and_names)

    original_cursor=query(cfg,graph).symbols(sha,limit=1).next_cursor
    for bad in ['not-base64','W10=',base64.urlsafe_b64encode(json.dumps([-1,'bad']).encode()).decode()]:
        case('invalid-cursor-'+str(len(CASES)),lambda bad=bad:reject(query(cfg,graph),'symbols',sha,limit=1,cursor=bad))
    def oversized_offset():
        offset,scope=json.loads(base64.urlsafe_b64decode(original_cursor))
        token=base64.urlsafe_b64encode(json.dumps([99999,scope]).encode()).decode()
        return reject(query(cfg,graph),'symbols',sha,limit=1,cursor=token)
    case('past-end-empty-page-rejected',oversized_offset)
    case('cross-query-cursor',lambda:reject(query(cfg,graph),'symbols',sha,name='f0',limit=1,cursor=original_cursor))
    newsha=commit(path,{'later.py':'def later():\n    return 1\n'},'second revision')
    cfg=cfg.model_copy(update={'revisions':[sha,newsha]}); index_repository(cfg,graph)
    fresh=query(cfg,graph).symbols(sha,limit=1).next_cursor
    case('cross-revision-cursor',lambda:reject(query(cfg,graph),'symbols',newsha,limit=1,cursor=fresh))
    case('expired-generation-cursor',lambda:reject(query(cfg,graph),'symbols',sha,limit=1,cursor=original_cursor))
    _,othercfg,othergraph,othersha=repo('other-repo',{'a.py':text})
    case('cross-repository-cursor',lambda:reject(query(othercfg,othergraph),'symbols',othersha,limit=1,cursor=fresh))
    index_repository(cfg,graph+'_copy')
    case('cross-graph-cursor',lambda:reject(query(cfg,graph+'_copy'),'symbols',sha,limit=1,cursor=fresh))

    def fanout():
        n=205
        text='def root():\n'+''.join(f'    f{i:03d}()\n' for i in range(n))+'\n'
        text+=''.join(f'def f{i:03d}():\n    pass\n\n' for i in range(n))
        expected=[['wide.root',f'wide.f{i:03d}','CALLS'] for i in range(n)]
        EXPECTED['fanout']=expected; save('expected-state.json',EXPECTED)
        p,c,g,s=repo('fanout',{'wide.py':text})
        items,records=pages(query(c,g),'dependencies',s,'wide.root',limit=200)
        actual=[[i.source,i.target,i.kind] for i in items]
        assert actual==expected and len(records)==2 and len(records[-1]['page']['items'])==5
        finding=investigate(c.name,s,'What does wide.root depend on?',config=c,graph_name=g)
        TRACES.append(dict(kind='fanout-investigation',result=clean(finding)))
        assert any(x.kind.lower()=='truncated' for x in finding.gaps)
        assert not (finding.answer and 'no depend' in finding.answer.lower())
        return dict(edges=n,pages=2,final_page_contains='wide.f204',investigation_gaps=[g.kind for g in finding.gaps])
    case('fanout-cap-plus-final-evidence',fanout)

    def history():
        p=OUT/'synthetic'/'history';p.mkdir(parents=True);git(p,'init','-q','-b','main')
        shas=[]
        for i in range(35):
            shas.append(commit(p,{'a.py':f'def repeated():\n    return {i}\n'},f'history {i:03d}'))
        expected=sorted(shas); EXPECTED['history-revisions']=expected;save('expected-state.json',EXPECTED)
        assert git(p,'rev-list','--count','HEAD')=='35'
        c=RepoConfig(name='history',path=str(p),revisions=shas); g='rw_t5_history'
        index_repository(c,g)
        items,records=pages(query(c,g),'revisions',limit=10)
        assert [i['sha'] for i in items]==expected and len(records)==4
        return dict(commits=35,pages=4,independent_git_count=35,final_page=items[-5:])
    case('long-history-revision-paging',history)

    for resource,limits in [('rows',ReadLimits(rows=1)),('source_bytes',ReadLimits(source_bytes=1)),('seconds',ReadLimits(seconds=1e-9))]:
        def exhausted(resource=resource,limits=limits):
            page=query(cfg,graph,limits=limits).symbols(sha)
            TRACES.append(dict(kind='resource-exhaustion',resource=resource,page=clean(page)))
            assert not page.items and page.truncated and page.coverage.get('complete') is False
            assert page.coverage['budget']['exhausted']==resource
            assert any(g.kind=='RETRIEVAL_BUDGET_EXHAUSTED' for g in page.coverage['gaps'])
            override={'query_max_rows':1} if resource=='rows' else {'query_max_source_bytes':1} if resource=='source_bytes' else {'query_timeout_seconds':1e-9}
            result=investigate(cfg.name,sha,'What does a.f0 depend on?',config=cfg.model_copy(update=override),graph_name=graph)
            TRACES.append(dict(kind='exhausted-investigation',resource=resource,result=clean(result)))
            assert result.answer is None and not result.findings and not result.facts and result.unresolved
            return dict(resource=resource,page_visible_partial=True,no_answer_or_findings=True,budget=page.coverage['budget'])
        case('resource-exhaustion-'+resource,exhausted)

    def edge_cap_component():
        old=Q.MAX_WALK_EDGES
        try:
            Q.MAX_WALK_EDGES=3 # Explicit component fault injection, not production 10000-edge evidence.
            p=query(cfg,graph).dependencies(sha,'a.f0',hops=5,limit=200)
            TRACES.append(dict(kind='reduced-edge-cap-fault-injection',configured_edges=3,page=clean(p)))
            assert len(p.items)==3 and p.coverage['frontier_truncated']
            assert any(g.kind=='TRUNCATED' for g in p.coverage['gaps'])
            return dict(component_only=True,production_cap_unchanged=old,page_truncated=p.truncated,
                        frontier_truncated=p.coverage['frontier_truncated'],coverage_gaps=[g.kind for g in p.coverage['gaps']])
        finally: Q.MAX_WALK_EDGES=old
    case('edge-cap-explicit-component-fault-injection',edge_cap_component)
except Exception as exc:
    CASES.append(dict(name='harness',status='FAIL',error=repr(exc),traceback=traceback.format_exc()))
finally:
    save('traces.json',TRACES);save('cases.json',CASES);save('expected-state.json',EXPECTED)
    if container:
        try:
            save('container-final-stats.json',cmd(['docker','stats','--no-stream','--format','{{json .}}',container]))
            cmd(['docker','rm','-f',container])
            save('cleanup.json',dict(removed_container=container,remaining_own_containers=cmd(['docker','ps','-a','--filter','name=rw-t5-audit-','--format','{{.ID}} {{.Names}}'])))
        except Exception as exc: save('cleanup-error.json',dict(error=repr(exc)))
    after=hashes();save('source-after.json',after)
    save('commands.json',COMMANDS)
    save('summary.json',dict(passed=sum(c['status']=='PASS' for c in CASES),failed=sum(c['status']=='FAIL' for c in CASES),
         source_unchanged=before==after,elapsed_seconds=time.monotonic()-START,full_T5_claim=False,
         missing=['Production 10000-edge cap boundary and cap+1; reduced-cap probe is component-only',
                  'Token exhaustion is not configured in RepoQuery; no provider/model invocation performed',
                  'No real-scale or held-out/model-answer completeness claim',
                  'Hop values 1..5 and invalid 0/6 exercised; no assertion that explicit depth means unbounded closure']))
    print(json.dumps(json.loads((OUT/'summary.json').read_text())),flush=True)
