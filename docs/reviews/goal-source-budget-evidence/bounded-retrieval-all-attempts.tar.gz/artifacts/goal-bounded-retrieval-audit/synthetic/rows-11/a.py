def f000():
    return 0

def f001():
    return 1

def f002():
    return 2

def f003():
    return 3

def f004():
    return 4

def f005():
    return 5

def f006():
    return 6

def f007():
    return 7

def f008():
    return 8

def f009():
    return 9

