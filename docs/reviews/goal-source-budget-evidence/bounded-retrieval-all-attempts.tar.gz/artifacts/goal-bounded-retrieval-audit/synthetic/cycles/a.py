def f0():
    f1()
    f2()
    f3()
    f4()

def f1():
    f0()

def f2():
    f5()

def f3():
    f5()

def f4():
    pass

def f5():
    f6()

def f6():
    f7()

def f7():
    f8()

def f8():
    pass

