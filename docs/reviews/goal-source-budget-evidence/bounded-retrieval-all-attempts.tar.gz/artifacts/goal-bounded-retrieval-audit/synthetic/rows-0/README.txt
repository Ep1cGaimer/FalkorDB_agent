No extractable symbols
