def repeated():
    return 34
