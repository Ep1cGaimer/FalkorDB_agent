"""Capture verified T0 inputs and explicit blockers without opening any tasks/oracles."""
import dataclasses,datetime,hashlib,json
from pathlib import Path
from confirmatory.gemini_meter import ModelLimits
from confirmatory.investigation_runner import ANSWER_SYSTEM,RETRIEVAL_SYSTEM
from confirmatory.tool_budget import ToolLimits

root=Path.cwd();out=root/'artifacts/goal-contract-readiness/readiness-001';out.mkdir(exist_ok=False)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
for name,text in [('retrieval-system.txt',RETRIEVAL_SYSTEM),('answer-system.txt',ANSWER_SYSTEM)]:
    (out/name).write_text(text)
for arm in ['graph','plaintext']:
    setup=json.loads((root/'artifacts/model-protocol-development/native-pilot-003'/arm/'setup.json').read_text())
    write(out/(arm+'-tool-contract.json'),setup['tool_descriptions'])
pin=root/'artifacts/goal-source-preflight/implementation-manifest.json'
corpus=json.loads((root/'artifacts/goal-contract-readiness/corpora-001/summary.json').read_text())
result={'schema':'goal-contract-readiness/v1','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'classification':'READINESS_ONLY_NOT_FROZEN_CONTRACT','acceptance_validated':False,'signed':False,
 'requirements_sha256':digest(root/'remquirements-v1.md'),
 'candidate_implementation':{'path':str(pin.relative_to(root)),'sha256':digest(pin),'files':199,
      'note':'Sourcebudgetrepair supersedes198-filebuild; oldtrials retain their originalpins. Current fullQA/fresh supplementary onboarding separately recorded.'},
 'exact_prompts':{name:digest(out/name) for name in ['retrieval-system.txt','answer-system.txt']},
 'tool_contracts':{name:digest(out/name) for name in ['graph-tool-contract.json','plaintext-tool-contract.json']},
 'model_limits_actual':dataclasses.asdict(ModelLimits()),'tool_limits_actual':dataclasses.asdict(ToolLimits()),
 'actual_parameter_contract':json.loads((root/'artifacts/model-protocol-development/native-pilot-003/graph/model-setup.json').read_text()),
 'corpora':[{'repository':x['repository'],'roots_spec':'artifacts/goal-contract-readiness/corpora-001/'+x['repository']+'-spec.json',
       'export_sha256':x['export_receipt']['corpus_sha256'],'serialized_bytes':x['export_receipt']['serialized_bytes'],
       'commits':x['export_receipt']['commits'],'included_unique_blobs':x['export_receipt']['included_unique_blobs'],
       'direct_context_sha256':x['direct_receipt']['context_sha256'],'direct_context_bytes':x['direct_receipt']['bytes'],
       'exact_model_tokens':None,'note':'New5-rootcandidatepayload; earlierdevelopmentcountsnotreusedasexactcounts'} for x in corpus['repositories']],
 'blocked_before_T0_signature':[
       'Exact countTokens totals for these new root/spec/identity serializations are unmeasured; provider429 remains recorded.',
       'Immutablemodelversion and exactdecoding settings remain unfrozen: metadata version3.0 differs from generationmodelVersiongemini-3.8-flash; current setup records providerdefaultparameters.',
       'Unsigneddraft proposedgraph/sourcebudgets differ from actualdevelopmentdefaults; reviewer must freeze a single final consistentcontract before any confirmatory attempt.',
       'No accepted model-driven developmentinvestigation; no empiricalquality/power pilot justifying GateB sample size.',
       'Pricing/billing and finalspend accounting unverified; inputtoken counts alone are not actualcost.',
       'Two independent blindscorers andthirdadjudicator exactidentities/modelprompts are notappointed.',
       'No signed-planconfirmatoryrunner or completedOSallowlist/accessproof for thatrunner; developmentrunner deliberately rejects CF-taskIDs.',
       'Fullcorpus/unseen-trialreconciliation required after199-filecorechange; oldClicktrial remainshistorical, freshsupplementaryFlasktrial pending separately.',
       'Independent frozen-planreview/signature absent; no confirmatorygeneration/scoring may run.'
 ],'provider_calls':0,'questions_or_oracles_read':False}
write(out/'readiness.json',result)
write(out/'manifest.json',{'schema':'readiness-artifact-hashes/v1','acceptance_validated':False,
       'files':{str(p.relative_to(out)):digest(p) for p in sorted(out.iterdir()) if p.is_file()}})
print(json.dumps({'readiness':'DRAFT_BLOCKED_NOT_SIGNED','corpora':len(result['corpora']),'exact_prompts':2,'provider_calls':0,'heldout_reads':False}))
