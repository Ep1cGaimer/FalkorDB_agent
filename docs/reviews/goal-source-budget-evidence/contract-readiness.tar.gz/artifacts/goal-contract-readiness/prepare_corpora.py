"""Prepare identical raw source/history inputs; never reads task/oracle contents."""
import concurrent.futures,datetime,hashlib,json,time
from pathlib import Path
from confirmatory.corpus_export import export_corpus
from confirmatory.direct_context import render_context

root=Path.cwd();out=root/'artifacts/goal-contract-readiness/corpora-001';out.mkdir(parents=True,exist_ok=False)
public=json.loads((root/'evals/confirmatory/corpus.draft-v1.json').read_text())
pin=json.loads((root/'docs/reviews/goal-hackathon-delivery-evidence/implementation-manifest.json').read_text())['files']
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,r):p.write_text(json.dumps(r,indent=2,default=str)+'\n')
assert all(digest(root/p)==h for p,h in pin.items())
write(out/'source-before.json',{'files':pin})
def one(name):
    data=public['repositories'][name]
    include=[name+'/*.py','src/'+name+'/*.py','pyproject.toml','setup.cfg','setup.py','HISTORY*','CHANGES*','CHANGELOG*']
    spec={'schema':'source-corpus-spec/v1','repository':name,
          'roots':[s['commit'] for s in data['snapshots']],
          'include':include,'exclude':['requests/packages/*'] if name=='requests' else []}
    write(out/(name+'-spec.json'),spec)
    started=time.monotonic()
    try:
        receipt=export_corpus(root/data['bare_path'],spec,out/name)
        context=render_context(out/name,out/(name+'-direct'))
        result={'repository':name,'status':'COMPLETE','seconds':time.monotonic()-started,
                'export_receipt':receipt,'direct_receipt':context,'tokens':'UNMEASURED; no provider call',
                'heldout_questions_read':False,'acceptance_validated':False}
    except Exception as exc:
        result={'repository':name,'status':'ERROR','error_type':type(exc).__name__,'seconds':time.monotonic()-started}
    write(out/(name+'-summary.json'),result)
    print(json.dumps({'repository':name,'status':result['status'],'seconds':result['seconds']}),flush=True)
    return result
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results=list(pool.map(one,['requests','click']))
write(out/'summary.json',{'classification':'UNSCORED_CANDIDATE_T0_CORPUS_PREPARATION_NOT_FROZEN',
     'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repositories':results,
     'provider_calls':0,'questions_or_oracles_read':False,
     'source_mismatches':[p for p,h in pin.items() if digest(root/p)!=h],
     'acceptance_validated':False})
