"""Fresh supplementary Flask onboarding; reviewer reads metadata, not source bodies."""
import dataclasses,datetime,fnmatch,hashlib,json,os,platform,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2];OUT=Path(__file__).resolve().parent
PIN=ROOT/'artifacts/goal-source-preflight/implementation-manifest.json'
def dump(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True,default=str)+'\n')
def digest(b):return hashlib.sha256(b).hexdigest()
def source_pin():
 expected=json.loads(PIN.read_text())['files'];actual={p:digest((ROOT/p).read_bytes()) for p in expected}
 return {'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'pin_path':str(PIN.relative_to(ROOT)),'pin_sha256':digest(PIN.read_bytes()),'count':len(actual),'expected':expected,'actual':actual,'all_match':expected==actual}
def command(argv,timeout=120):
 start=time.monotonic();p=subprocess.run(argv,capture_output=True,text=True,timeout=timeout)
 row={'argv':argv,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-start}
 with (OUT/'commands.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
 if p.returncode:raise RuntimeError(str(argv)+': '+p.stderr)
 return p.stdout.strip()
def main():
 OUT.mkdir(parents=True,exist_ok=True);start=time.monotonic();dump('source-before.json',source_pin())
 dump('predeclaration.json',{'target':'https://github.com/pallets/flask.git','tag':'3.1.2','reviewer_source_exposure':'No Flask source bodies inspected during this session before this trial. No held-out questions or expected answers accessed. Only Git metadata is manually reviewed; production ingestion may read object bytes.','purpose':'supplementary fresh configuration-only onboarding for199-file repair candidate; does not replace planned Requests/Click corpus or establish T0/T1','budget_seconds':360,'core_edits_allowed':False,'adapter_edits_allowed':False,'model_calls_allowed':False})
 repo=OUT/'flask.git';clone_start=time.monotonic();command(['git','clone','--bare','https://github.com/pallets/flask.git',str(repo)],timeout=120)
 def git(*args):return command(['git','--no-pager','-C',str(repo),*args])
 fullsha=git('rev-parse','--verify','3.1.2^{commit}');assert len(fullsha)==40
 tag_object=git('rev-parse','refs/tags/3.1.2')
 metadata={'remote':git('remote','get-url','origin'),'bare':git('rev-parse','--is-bare-repository'),'tag':'3.1.2','tag_object':tag_object,'selected_sha':fullsha,'selected_commit':git('show','--no-patch','--format=%H%n%P%n%at%n%ct','3.1.2^{commit}'),'reachable_commits':int(git('rev-list','--count',fullsha)),'clone_seconds':time.monotonic()-clone_start}
 tree=git('ls-tree','-r','-l','--full-tree',fullsha);dump('selected-tree-metadata.json',tree.splitlines())
 include=['src/flask/*.py','pyproject.toml','CHANGES.rst','README.md','LICENSE.txt']
 selected=[]
 for line in tree.splitlines():
  fields,path=line.split('\t',1);mode,kind,oid,size=fields.split()
  if mode in ('100644','100755') and kind=='blob' and any(fnmatch.fnmatchcase(path,g) for g in include):selected.append({'path':path,'git_blob':oid,'bytes':int(size),'mode':mode})
 metadata['expected_selected_files']=selected;metadata['python_file_count']=sum(p['path'].endswith('.py') for p in selected);metadata['selected_bytes']=sum(p['bytes'] for p in selected)
 dump('git-metadata.json',metadata)
 cfg={'name':'fresh-flask-199','path':str(repo),'revisions':[fullsha],'tag_pattern':None,'languages':['python'],'include':include,'exclude':[],'path_matching':'path','regular_files_only':True,'release_notes':['CHANGES.rst']}
 dump('config.json',cfg)
 # Child timeout bounds the import independently of the reviewer's process.
 env={**os.environ,'PYTHONPATH':str(ROOT/'src')}
 cmd=[sys.executable,str(Path(__file__).resolve()),'--index']
 begin=time.monotonic();p=subprocess.run(cmd,capture_output=True,text=True,env=env,timeout=240)
 dump('index-process.json',{'argv':cmd,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'seconds':time.monotonic()-begin})
 if p.returncode:raise RuntimeError('index child failed; raw output retained')
 dump('source-after.json',source_pin());dump('summary.json',{'status':'PASS' if json.loads((OUT/'index-result.json').read_text())['pass'] and source_pin()['all_match'] else 'FAIL','seconds':time.monotonic()-start,'selected_sha':fullsha,'configuration_only':True,'core_or_adapter_changes':0,'model_calls':0,'python_file_count':metadata['python_file_count'],'selected_file_count':len(selected),'selected_bytes':metadata['selected_bytes'],'reachable_commits':metadata['reachable_commits'],'claim':'supplementary onboarding only; not full T0/T1 or a replacement evaluation corpus'})
 print((OUT/'summary.json').read_text(),flush=True)
def index():
 from rw import graph as G
 from rw.repo.config import load_config
 from rw.repo.index import index_repository
 from rw.repo.query import RepoQuery
 cfg=load_config(OUT/'config.json');db=G.connect(port=int(os.environ.get('RW_FRESH_ONBOARDING_PORT','60858')));trace=[]
 started=time.monotonic();report=index_repository(cfg,'fresh_flask_199',db=db);elapsed=time.monotonic()-started
 q=RepoQuery('fresh_flask_199',cfg.name,db=db,trace=trace);resolved,gap=q.resolve(cfg.revisions[0])
 rows=q._q('MATCH (:Commit {sha:$s})-[f:HAS_FILE]->(b:Blob) RETURN f.path,b.git_sha,b.size ORDER BY f.path',{'s':cfg.revisions[0]})
 expected=json.loads((OUT/'git-metadata.json').read_text())['expected_selected_files'];want=sorted([[p['path'],p['git_blob'],p['bytes']] for p in expected])
 repository=db.select_graph('fresh_flask_199').ro_query('MATCH (r:Repository) RETURN properties(r)').result_set
 passed=report.status=='COMPLETE' and resolved==cfg.revisions[0] and gap is None and rows==want and not report.extraction_errors
 dump('index-result.json',{'pass':passed,'report':dataclasses.asdict(report),'index_seconds':elapsed,'resolve':{'requested':cfg.revisions[0],'actual':resolved,'gap':dataclasses.asdict(gap) if gap else None},'selected_graph_files':rows,'expected_selected_files':want,'selected_file_map_matches':rows==want,'repository_publication':repository,'trace':trace})
 print(json.dumps({'pass':passed,'status':report.status,'commits':report.commits,'blobs':report.blobs,'symbols':report.symbols,'relations':report.relations,'selected_file_map_matches':rows==want,'extraction_errors':len(report.extraction_errors),'seconds':elapsed}),flush=True)
if __name__=='__main__':
 try:index() if '--index' in sys.argv else main()
 except BaseException:
  dump('error.json',{'error':traceback.format_exc(),'source_pin':source_pin()});raise
